<?php
$page_title = "Contact Us";
$active_page = "contact";
$base_path = "./";
require_once 'includes/config.php';

$errors = [];
$success_msg = '';

// Handle Form Submission
if (isset($_POST['send_message'])) {
    // 1. Sanitization
    $name = sanitize_input($_POST['name']);
    $email = sanitize_input($_POST['email']);
    $subject = sanitize_input($_POST['subject']);
    $message = sanitize_input($_POST['message']);
    
    // 2. Server-side Validation
    if (empty($name)) {
        $errors['name'] = "Your name is required.";
    }
    
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = "A valid email address is required.";
    }
    
    if (empty($subject)) {
        $errors['subject'] = "Subject is required.";
    }
    
    if (empty($message) || strlen($message) < 10) {
        $errors['message'] = "Message must be at least 10 characters long.";
    }
    
    // If no errors, process (e.g. store in db or send email). 
    // Since we don't have a contact table in the requirements, we'll store success in session and redirect
    if (empty($errors)) {
        $_SESSION['success'] = "Thank you, " . htmlspecialchars($name) . "! Your message has been sent successfully.";
        header("Location: contact-us.php");
        exit();
    }
}

require_once 'includes/header.php';
?>

<section>
    <div class="two-col-layout" style="margin-top: 2rem;">
        <!-- Contact Info Left Column -->
        <div class="contact-info">
            <h2 style="font-family: var(--font-heading); font-size: 2.5rem; margin-bottom: 1.5rem;">Get In <span>Touch</span></h2>
            <p>We are here to help you. Send us a message and we will get back to you as soon as possible.</p>
            
            <div class="contact-details">
                <div class="contact-detail-item">
                    <div class="contact-detail-icon"><i class="fas fa-phone-alt"></i></div>
                    <div>
                        <div style="font-size: 0.8rem; color: var(--text-secondary);">Call Us</div>
                        <div style="font-weight: 600;">+91 98765 43210</div>
                    </div>
                </div>
                
                <div class="contact-detail-item">
                    <div class="contact-detail-icon"><i class="fas fa-envelope"></i></div>
                    <div>
                        <div style="font-size: 0.8rem; color: var(--text-secondary);">Email Us</div>
                        <div style="font-weight: 600;">info@theatrehub.com</div>
                    </div>
                </div>
                
                <div class="contact-detail-item">
                    <div class="contact-detail-icon"><i class="fas fa-map-marker-alt"></i></div>
                    <div>
                        <div style="font-size: 0.8rem; color: var(--text-secondary);">Our Location</div>
                        <div style="font-weight: 600;">ICST University Park - Punanai</div>
                    </div>
                </div>
            </div>
            
            <div class="social-links" style="margin-top: 2rem;">
                <a href="#" class="social-icon" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                <a href="#" class="social-icon" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
                <a href="#" class="social-icon" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                <a href="#" class="social-icon" aria-label="YouTube"><i class="fab fa-youtube"></i></a>
            </div> 
        </div>
        
        <!-- Contact Form Right Column -->
        <div>
            <form method="POST" action="contact-us.php" id="contact-form" class="card-form" style="text-align: left;">
                <h3 style="text-align: left; font-size: 1.6rem; margin-bottom: 2rem; border-bottom: 2px solid var(--primary-color); padding-bottom: 0.5rem; display: inline-block;">Send Message</h3>
                
                <div class="form-group">
                    <label for="name">Your Name</label>
                    <input type="text" name="name" id="name" class="form-control" placeholder="John Doe" value="<?= isset($name) ? htmlspecialchars($name) : '' ?>" required>
                    <?php if (isset($errors['name'])): ?>
                        <span style="color: var(--danger-color); font-size: 0.8rem;"><?= $errors['name'] ?></span>
                    <?php endif; ?>
                </div>
                
                <div class="form-group">
                    <label for="email">Your Email</label>
                    <input type="email" name="email" id="email" class="form-control" placeholder="john@example.com" value="<?= isset($email) ? htmlspecialchars($email) : '' ?>" required>
                    <?php if (isset($errors['email'])): ?>
                        <span style="color: var(--danger-color); font-size: 0.8rem;"><?= $errors['email'] ?></span>
                    <?php endif; ?>
                </div>
                
                <div class="form-group">
                    <label for="subject">Subject</label>
                    <input type="text" name="subject" id="subject" class="form-control" placeholder="Booking Inquiry" value="<?= isset($subject) ? htmlspecialchars($subject) : '' ?>" required>
                    <?php if (isset($errors['subject'])): ?>
                        <span style="color: var(--danger-color); font-size: 0.8rem;"><?= $errors['subject'] ?></span>
                    <?php endif; ?>
                </div>
                
                <div class="form-group">
                    <label for="message">Your Message</label>
                    <textarea name="message" id="message" class="form-control" placeholder="How can we help you?" required><?= isset($message) ? htmlspecialchars($message) : '' ?></textarea>
                    <?php if (isset($errors['message'])): ?>
                        <span style="color: var(--danger-color); font-size: 0.8rem;"><?= $errors['message'] ?></span>
                    <?php endif; ?>
                </div>
                
                <button type="submit" name="send_message" class="btn btn-primary" style="width: 100%; margin-top: 1rem; border-radius: 8px;">
                    <i class="fas fa-paper-plane"></i> Send Message
                </button>
            </form>
        </div>
    </div>
</section>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            let isValid = true;
            const name = document.getElementById('name');
            const email = document.getElementById('email');
            const subject = document.getElementById('subject');
            const message = document.getElementById('message');

            const showError = (input, msg) => {
                const group = input.parentElement;
                let error = group.querySelector('.js-error');
                if (!error) {
                    error = document.createElement('span');
                    error.className = 'js-error';
                    error.style.color = 'var(--danger-color)';
                    error.style.fontSize = '0.8rem';
                    error.style.marginTop = '0.25rem';
                    error.style.display = 'block';
                    group.appendChild(error);
                }
                error.textContent = msg;
                input.style.borderColor = 'var(--danger-color)';
            };

            const clearError = (input) => {
                const group = input.parentElement;
                const error = group.querySelector('.js-error');
                if (error) error.remove();
                input.style.borderColor = '';
            };

            if (name.value.trim() === '') {
                showError(name, 'Your name is required.');
                isValid = false;
            } else {
                clearError(name);
            }

            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email.value.trim())) {
                showError(email, 'A valid email address is required.');
                isValid = false;
            } else {
                clearError(email);
            }

            if (subject.value.trim() === '') {
                showError(subject, 'Subject is required.');
                isValid = false;
            } else {
                clearError(subject);
            }

            if (message.value.trim().length < 10) {
                showError(message, 'Message must be at least 10 characters long.');
                isValid = false;
            } else {
                clearError(message);
            }

            if (!isValid) {
                e.preventDefault();
            }
        });
    }
});
</script>

<?php require_once 'includes/footer.php'; ?>
