<?php
require_once 'includes/config.php';

// Unset all session variables
$_SESSION = [];

// Destroy the session cookie if exists
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Destroy session
session_destroy();

// Start a new session just to show the success message
session_start();
$_SESSION['success'] = "You have been logged out successfully.";

header("Location: index.php");
exit();
?>
