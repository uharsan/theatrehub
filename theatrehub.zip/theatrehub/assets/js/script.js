document.addEventListener('DOMContentLoaded', () => {
    // 1. Dark/Light Mode Switcher
    const themeSwitchBtn = document.getElementById('theme-switch');
    const themeIcon = themeSwitchBtn ? themeSwitchBtn.querySelector('i') : null;
    
    // Check local storage for theme
    const currentTheme = localStorage.getItem('theme') || 'dark';
    document.documentElement.setAttribute('data-theme', currentTheme);
    updateThemeIcon(currentTheme);

    if (themeSwitchBtn) {
        themeSwitchBtn.addEventListener('click', () => {
            let theme = document.documentElement.getAttribute('data-theme');
            let newTheme = (theme === 'dark') ? 'light' : 'dark';
            document.documentElement.setAttribute('data-theme', newTheme);
            localStorage.setItem('theme', newTheme);
            updateThemeIcon(newTheme);
        });
    }

    function updateThemeIcon(theme) {
        if (!themeIcon) return;
        if (theme === 'light') {
            themeIcon.className = 'fas fa-moon';
            themeSwitchBtn.title = 'Switch to Dark Mode';
        } else {
            themeIcon.className = 'fas fa-sun';
            themeSwitchBtn.title = 'Switch to Light Mode';
        }
    }

    // 2. Mobile Navigation Toggle
    const mobileNavToggle = document.getElementById('mobile-nav-toggle');
    const navMenu = document.querySelector('nav ul');

    if (mobileNavToggle && navMenu) {
        mobileNavToggle.addEventListener('click', () => {
            navMenu.classList.toggle('active');
            const icon = mobileNavToggle.querySelector('i');
            if (icon) {
                icon.classList.toggle('fa-bars');
                icon.classList.toggle('fa-times');
            }
        });
    }

    // 3. Auto-fade alert notifications
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
            alert.style.opacity = '0';
            alert.style.transform = 'translateY(-10px)';
            setTimeout(() => {
                alert.remove();
            }, 800);
        }, 4000);
    });

    // 4. Client-side Form Validations
    
    // Helper to show inline validation errors
    const showError = (input, message) => {
        const formGroup = input.parentElement;
        let errorEl = formGroup.querySelector('.invalid-feedback');
        if (!errorEl) {
            errorEl = document.createElement('div');
            errorEl.className = 'invalid-feedback';
            errorEl.style.color = '#e63946';
            errorEl.style.fontSize = '0.75rem';
            errorEl.style.marginTop = '0.25rem';
            formGroup.appendChild(errorEl);
        }
        errorEl.textContent = message;
        input.style.borderColor = '#e63946';
    };

    const clearError = (input) => {
        const formGroup = input.parentElement;
        const errorEl = formGroup.querySelector('.invalid-feedback');
        if (errorEl) {
            errorEl.remove();
        }
        input.style.borderColor = '';
    };

    // Registration Form Validation
    const registerForm = document.getElementById('register-form');
    if (registerForm) {
        registerForm.addEventListener('submit', (e) => {
            let isValid = true;
            const fullname = document.getElementById('fullname');
            const email = document.getElementById('email');
            const phone = document.getElementById('phone');
            const password = document.getElementById('password');
            const confirmPassword = document.getElementById('confirm_password');

            // Name validation
            if (fullname.value.trim() === '') {
                showError(fullname, 'Full name is required');
                isValid = false;
            } else {
                clearError(fullname);
            }

            // Email validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email.value.trim())) {
                showError(email, 'Please enter a valid email address');
                isValid = false;
            } else {
                clearError(email);
            }

            // Phone validation
            if (phone.value.trim() === '') {
                showError(phone, 'Phone number is required');
                isValid = false;
            } else {
                clearError(phone);
            }

            // Password length check
            if (password.value.length < 6) {
                showError(password, 'Password must be at least 6 characters long');
                isValid = false;
            } else {
                clearError(password);
            }

            // Confirm Password check
            if (password.value !== confirmPassword.value) {
                showError(confirmPassword, 'Passwords do not match');
                isValid = false;
            } else {
                clearError(confirmPassword);
            }

            if (!isValid) {
                e.preventDefault();
            }
        });
    }

    // Login Form Validation
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            let isValid = true;
            const email = document.getElementById('email');
            const password = document.getElementById('password');

            if (email.value.trim() === '') {
                showError(email, 'Email is required');
                isValid = false;
            } else {
                clearError(email);
            }

            if (password.value.trim() === '') {
                showError(password, 'Password is required');
                isValid = false;
            } else {
                clearError(password);
            }

            if (!isValid) {
                e.preventDefault();
            }
        });
    }

    // Feature Form Validation (Add/Edit Feature)
    const featureForm = document.getElementById('feature-form');
    if (featureForm) {
        featureForm.addEventListener('submit', (e) => {
            let isValid = true;
            const name = document.getElementById('features_name');
            const desc = document.getElementById('description');
            const facilities = document.getElementById('facilities');
            const imageInput = document.getElementById('image');

            if (name.value.trim() === '') {
                showError(name, 'Feature name is required');
                isValid = false;
            } else {
                clearError(name);
            }

            if (desc.value.trim() === '') {
                showError(desc, 'Description is required');
                isValid = false;
            } else {
                clearError(desc);
            }

            if (facilities.value.trim() === '') {
                showError(facilities, 'Facilities are required');
                isValid = false;
            } else {
                clearError(facilities);
            }

            // Image is only required on dynamic insertion (Add form), not edit (which retains existing)
            if (imageInput && imageInput.hasAttribute('required') && imageInput.files.length === 0) {
                showError(imageInput, 'Please upload a feature poster image');
                isValid = false;
            } else if (imageInput) {
                clearError(imageInput);
            }

            if (!isValid) {
                e.preventDefault();
            }
        });
    }
});
