<?php
require_once 'includes/config.php';
if(!isset($_SESSION['user_id'])){ header("Location: login.php"); exit(); }

$show_id = $_GET['show_id'] ?? 0;
$stmt = $pdo->prepare("SELECT s.*, m.title FROM shows s JOIN movies m ON s.movie_id = m.movie_id WHERE s.show_id = ?");
$stmt->execute([$show_id]);
$show = $stmt->fetch();
if(!$show){ die("Show not found"); }

$stmt = $pdo->prepare("SELECT seats FROM bookings WHERE show_id = ?");
$stmt->execute([$show_id]);
$booked = [];
while($row = $stmt->fetch()){
    $booked = array_merge($booked, explode(',', $row['seats']));
}

$rows = ['A','B','C','D','E','F'];
$cols = 10;
?>
<!DOCTYPE html>
<html>
<head>
    <title>Select Seats - <?= $show['title'] ?></title>
    <style>
        body { font-family: Arial; text-align: center; padding: 20px; }
        .screen { background: #ccc; padding: 10px; margin: 20px auto; width: 300px; }
        .seats { display: inline-block; }
        .seat { width: 35px; height: 35px; margin: 3px; border: 1px solid #999; border-radius: 5px; cursor: pointer; background: white; }
        .seat.available:hover { background: #28a745; color: white; }
        .booked { background: #dc3545; color: white; cursor: not-allowed; }
        .selected { background: #007bff !important; color: white; }
        #book-btn { background: #ccc; color: white; padding: 15px 40px; border: none; border-radius: 5px; font-size: 18px; cursor: not-allowed; margin-top: 20px; }
    </style>
</head>
<body>
    <h2><?= $show['title'] ?></h2>
    <p>Date: <?= date('d-m-Y', strtotime($show['show_date'])) ?> | Time: <?= date('h:i A', strtotime($show['show_time'])) ?></p>
    <p>Screen: <?= $show['screen_name'] ?> | Price: LKR <?= $show['price'] ?></p>
    
    <div class="screen">SCREEN THIS SIDE</div>
    
    <div class="seats">
        <?php foreach($rows as $r): ?>
            <div>
                <?php for($c=1; $c<=$cols; $c++): 
                    $seat = $r.$c;
                    $class = in_array($seat, $booked) ? 'booked' : 'available';
                ?>
                    <button class="seat <?= $class ?>" data-seat="<?= $seat ?>" <?= $class=='booked'?'disabled':'' ?>><?= $seat ?></button>
                <?php endfor; ?>
            </div>
        <?php endforeach; ?>
    </div>
    
    <p style="margin-top:20px;">
        <span style="background:white; border:1px solid #999; padding:2px 8px;">Available</span>
        <span style="background:#007bff; color:white; padding:2px 8px;">Selected</span>
        <span style="background:#dc3545; color:white; padding:2px 8px;">Booked</span>
    </p>
    
    <p>Selected Seats: <span id="selected-seats">None</span></p>
    <p>Total Amount: <span id="total-amount">LKR 0</span></p>
    
    <button id="book-btn" disabled>Confirm Booking</button>
    
    <form id="book-form" action="book.php" method="POST" style="display:none;">
        <input type="hidden" name="show_id" value="<?= $show_id ?>">
        <input type="hidden" name="seats" id="seats-input">
        <input type="hidden" name="total" id="total-input">
    </form>

<script>
const seats = document.querySelectorAll('.seat.available');
const bookBtn = document.getElementById('book-btn');
const totalAmount = document.getElementById('total-amount');
const selectedSeatsText = document.getElementById('selected-seats');
let selected = [];
const price = <?= $show['price'] ?>;

seats.forEach(seat => {
    seat.addEventListener('click', () => {
        if(seat.classList.contains('selected')){
            seat.classList.remove('selected');
            selected = selected.filter(s => s !== seat.dataset.seat);
        } else {
            seat.classList.add('selected');
            selected.push(seat.dataset.seat);
        }
        
        if(selected.length > 0){
            bookBtn.disabled = false;
            bookBtn.style.background = '#007bff';
            bookBtn.style.cursor = 'pointer';
            bookBtn.textContent = `Confirm Booking - LKR ${selected.length * price}`;
            selectedSeatsText.textContent = selected.join(', ');
            totalAmount.textContent = 'LKR ' + (selected.length * price);
        } else {
            bookBtn.disabled = true;
            bookBtn.style.background = '#ccc';
            bookBtn.style.cursor = 'not-allowed';
            bookBtn.textContent = 'Confirm Booking';
            selectedSeatsText.textContent = 'None';
            totalAmount.textContent = 'LKR 0';
        }
    });
});

bookBtn.addEventListener('click', () => {
    if(selected.length === 0) return;
    if(confirm(`Confirm booking ${selected.length} seats for LKR ${selected.length * price}?`)){
        document.getElementById('seats-input').value = selected.join(',');
        document.getElementById('total-input').value = selected.length * price;
        document.getElementById('book-form').submit();
    }
});
</script>
</body>
</html>