<?php
$page_title = "About Us";
$active_page = "about";
$base_path = "./";
require_once 'includes/config.php';
require_once 'includes/header.php';
?>

<div class="hero" style="padding: 4rem 2rem 2rem 2rem;">
    <div class="hero-container" style="gap: 2rem;">
        <div class="hero-content">
            <h1 style="font-size: 3rem;">About <span>Us</span></h1>
            <p style="font-size: 1.05rem; line-height: 1.7;">
                <strong>TheatreHub</strong> is the best place to enjoy the latest movies with premium sound and comfortable seating. Founded with a vision to redefine the cinematic experience, we have consistently pushed boundaries to offer our viewers state-of-the-art entertainment.
            </p>
            <p style="color: var(--text-secondary); font-size: 0.95rem; line-height: 1.6; margin-bottom: 2rem;">
                Our theatres are equipped with full-RGB laser projectors and Dolby Atmos surround systems that put you right inside the action. From box-office blockbusters to indie cinema, we provide a curated selection of films for every movie enthusiast.
            </p>
            <div class="hero-actions">
                <a href="features.php" class="btn btn-primary"><i class="fas fa-ticket-alt"></i> Browse Movies</a>
                <a href="contact-us.php" class="btn btn-outline"><i class="fas fa-envelope"></i> Contact Us</a>
            </div>
        </div>
        <div class="hero-image" style="max-height: 380px;">
            <img src="https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=600&q=80" alt="Cinema screen projection hall with red chairs">
        </div>
    </div>
</div>

<!-- Stats Banner -->
<div class="stats-banner">
    <div class="stats-container">
        <div class="stat-item">
            <h2>10+</h2>
            <p>Screens Available</p>
        </div>
        <div class="stat-item">
            <h2>500K+</h2>
            <p>Happy Customers</p>
        </div>
        <div class="stat-item">
            <h2>50+</h2>
            <p>Movies Screened</p>
        </div>
        <div class="stat-item">
            <h2>24/7</h2>
            <p>Customer Support</p>
        </div>
    </div>
</div>

<!-- Feature items details -->
<section>
    <div class="section-title" style="text-align: center; margin-bottom: 4rem;">
        <h2>Redefining Cinema Standards</h2>
        <p>A closer look at how we deliver premium entertainment</p>
    </div>
    
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 3rem; align-items: center; margin-bottom: 4rem;">
        <div>
            <img src="https://images.unsplash.com/photo-1478720568477-152d9b164e26?auto=format&fit=crop&w=500&q=80" alt="Cinema camera lens projection" style="width:100%; border-radius: var(--border-radius); border: 1px solid var(--border-color); box-shadow: 0 10px 30px var(--shadow-color);">
        </div>
        <div>
            <h3 style="font-family: var(--font-heading); font-size: 1.8rem; margin-bottom: 1rem; color: var(--text-primary);"><i class="fas fa-bullseye" style="color: var(--primary-color); margin-right: 10px;"></i>Our Vision & Mission</h3>
            <p style="color: var(--text-secondary); line-height: 1.6; margin-bottom: 1.5rem;">
                Our mission is to transport audiences into spectacular worlds of imagination. We achieve this by integrating the finest technology, premium architectural designs, and stellar guest services.
            </p>
            <ul style="list-style: none; display: flex; flex-direction: column; gap: 10px; color: var(--text-secondary); font-size: 0.95rem;">
                <li><i class="fas fa-check-circle" style="color: var(--success-color); margin-right: 8px;"></i> Ultra-High Resolution Laser Projection Systems</li>
                <li><i class="fas fa-check-circle" style="color: var(--success-color); margin-right: 8px;"></i> Next-Generation Acoustics & Acoustical Wall Insulation</li>
                <li><i class="fas fa-check-circle" style="color: var(--success-color); margin-right: 8px;"></i> Luxurious Recliners with USB charging and seat warmers</li>
                <li><i class="fas fa-check-circle" style="color: var(--success-color); margin-right: 8px;"></i> Safe, encrypted ticket checkout & automated entries</li>
            </ul>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
