<?php
require_once 'includes/config.php';
require_once 'vendor/dompdf/dompdf/src/Autoloader.php';
Dompdf\Autoloader::register();

use Dompdf\Dompdf;

if(!isset($_SESSION['user_id'])){ header("Location: login.php"); exit(); }

$booking_id = $_GET['id'] ?? 0;

$stmt = $pdo->prepare("SELECT b.*, s.show_date, s.show_time, s.screen_name, m.title, m.duration, u.username 
                       FROM bookings b 
                       JOIN shows s ON b.show_id = s.show_id 
                       JOIN movies m ON s.movie_id = m.movie_id 
                       JOIN users u ON b.user_id = u.user_id 
                       WHERE b.booking_id = ? AND b.user_id = ?");
$stmt->execute([$booking_id, $_SESSION['user_id']]);
$b = $stmt->fetch();

if(!$b){ die("Ticket not found"); }

$html = '
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body { font-family: DejaVu Sans, sans-serif; }
        .ticket { border: 3px dashed #007bff; padding: 20px; width: 500px; margin: 20px auto; }
        h1 { text-align: center; color: #007bff; margin-bottom: 20px; font-size: 24px; }
        .row { margin: 12px 0; font-size: 14px; }
        .label { font-weight: bold; display: inline-block; width: 130px; }
        .seats { background: #28a745; color: white; padding: 5px 12px; border-radius: 4px; font-weight: bold; }
        .footer { text-align: center; margin-top: 25px; font-size: 11px; color: #666; border-top: 1px solid #ddd; padding-top: 15px; }
    </style>
</head>
<body>
    <div class="ticket">
        <h1>THEATREHUB - E-TICKET</h1>
        <div class="row"><span class="label">Booking ID:</span> #'.$b['booking_id'].'</div>
        <div class="row"><span class="label">Name:</span> '.htmlspecialchars($b['username']).'</div>
        <div class="row"><span class="label">Movie:</span> '.htmlspecialchars($b['title']).'</div>
        <div class="row"><span class="label">Duration:</span> '.$b['duration'].' mins</div>
        <div class="row"><span class="label">Date:</span> '.date('d M Y, l', strtotime($b['show_date'])).'</div>
        <div class="row"><span class="label">Time:</span> '.date('h:i A', strtotime($b['show_time'])).'</div>
        <div class="row"><span class="label">Screen:</span> '.htmlspecialchars($b['screen_name']).'</div>
        <div class="row"><span class="label">Seats:</span> <span class="seats">'.$b['seats'].'</span></div>
        <div class="row"><span class="label">Amount:</span> LKR '.$b['total_amount'].'</div>
        <div class="row"><span class="label">Status:</span> <b style="color: green;">CONFIRMED</b></div>
        <div class="row"><span class="label">Booked On:</span> '.date('d-m-Y h:i A', strtotime($b['booking_date'])).'</div>
        <div class="footer">Show this ticket at the counter. Valid ID required.<br>Thank you for booking with TheatreHub!</div>
    </div>
</body>
</html>';

$dompdf = new Dompdf();
$dompdf->loadHtml($html, 'UTF-8');
$dompdf->setPaper('A5', 'portrait');
$dompdf->render();
$dompdf->stream("TheatreHub_Ticket_".$b['booking_id'].".pdf", ["Attachment" => true]);
?>