<?php
$page_title = "My Profile";
$active_page = "profile";
$base_path = "./";
require_once 'includes/config.php';

// Access guard
require_login();

$user_id = $_SESSION['user_id'];
$errors = [];
$pw_errors = [];

// Fetch latest user details from DB
try {
    $stmt = $pdo->prepare("SELECT * FROM `users` WHERE `user_id` = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}

// Handle Profile Info Update
if (isset($_POST['update_profile'])) {
    $fullname = sanitize_input($_POST['fullname']);
    $phone = sanitize_input($_POST['phone']);
    
    if (empty($fullname)) {
        $errors['fullname'] = "Full name is required.";
    }
    
    if (empty($phone)) {
        $errors['phone'] = "Phone number is required.";
    }
    
    if (empty($errors)) {
        try {
            $upd_stmt = $pdo->prepare("UPDATE `users` SET `fullname` = ?, `phone` = ? WHERE `user_id` = ?");
            $upd_stmt->execute([$fullname, $phone, $user_id]);
            
            // Update session values
            $_SESSION['fullname'] = $fullname;
            $_SESSION['phone'] = $phone;
            
            $_SESSION['success'] = "Profile updated successfully!";
            header("Location: profile.php");
            exit();
        } catch (PDOException $e) {
            $errors['db'] = "Failed to update profile: " . $e->getMessage();
        }
    }
}

// Handle Password Change
if (isset($_POST['change_password'])) {
    $current_pw = $_POST['current_password'];
    $new_pw = $_POST['new_password'];
    $confirm_new_pw = $_POST['confirm_new_password'];
    
    if (empty($current_pw)) {
        $pw_errors['current'] = "Current password is required.";
    }
    
    if (strlen($new_pw) < 6) {
        $pw_errors['new'] = "New password must be at least 6 characters long.";
    }
    
    if ($new_pw !== $confirm_new_pw) {
        $pw_errors['confirm'] = "Passwords do not match.";
    }
    
    if (empty($pw_errors)) {
        try {
            // Verify current password first
            if (password_verify($current_pw, $user['password'])) {
                $new_hashed = password_hash($new_pw, PASSWORD_BCRYPT);
                
                $pw_stmt = $pdo->prepare("UPDATE `users` SET `password` = ? WHERE `user_id` = ?");
                $pw_stmt->execute([$new_hashed, $user_id]);
                
                $_SESSION['success'] = "Password changed successfully!";
                header("Location: profile.php");
                exit();
            } else {
                $pw_errors['current'] = "Incorrect current password.";
            }
        } catch (PDOException $e) {
            $pw_errors['db'] = "Failed to change password: " . $e->getMessage();
        }
    }
}

require_once 'includes/header.php';
?>

<div class="dashboard-grid">
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-title">Menu</div>
        <ul class="sidebar-menu">
            <li><a href="dashboard.php"><i class="fas fa-ticket-alt"></i> My Bookings</a></li>
            <li><a href="profile.php" class="active"><i class="fas fa-user-circle"></i> Profile</a></li>
            <li><a href="profile.php#change-password"><i class="fas fa-key"></i> Change Password</a></li>
            <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </aside>

    <!-- Main Content -->
    <main class="dashboard-content">
        
        <!-- Profile Header Panel -->
        <div class="profile-card">
            <div class="profile-avatar-container">
                <!-- Fallback to a high quality avatar image -->
                <img src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80" alt="Avatar">
            </div>
            <div class="profile-summary">
                <h3><?= htmlspecialchars($user['fullname']) ?></h3>
                <p><i class="fas fa-envelope" style="color: var(--primary-color); margin-right: 8px;"></i> <?= htmlspecialchars($user['email']) ?></p>
                <div style="margin-top: 8px;">
                    <span class="badge badge-user" style="text-transform: uppercase; font-size: 0.7rem; font-weight: 700;"><?= htmlspecialchars($user['role']) ?></span>
                    <span style="font-size: 0.8rem; color: var(--text-secondary); margin-left: 10px;">Joined <?= date('d M Y', strtotime($user['created_at'])) ?></span>
                </div>
            </div>
        </div>

        <div style="display: grid; grid-template-columns: 1.2fr 1fr; gap: 2rem;">
            <!-- Profile Information Form -->
            <div class="card-form" style="text-align: left; box-shadow: none;">
                <h3 style="text-align: left; font-size: 1.25rem; border-bottom: 1px solid var(--border-color); padding-bottom: 0.75rem; margin-bottom: 1.5rem;">Update Info</h3>
                
                <?php if (isset($errors['db'])): ?>
                    <div class="alert alert-danger"><?= $errors['db'] ?></div>
                <?php endif; ?>
                
                <form method="POST" action="profile.php">
                    <div class="form-group">
                        <label for="fullname">Full Name</label>
                        <input type="text" name="fullname" id="fullname" class="form-control" value="<?= htmlspecialchars($user['fullname']) ?>" required>
                        <?php if (isset($errors['fullname'])): ?>
                            <span style="color: var(--danger-color); font-size: 0.8rem;"><?= $errors['fullname'] ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group">
                        <label>Email Address (Cannot be changed)</label>
                        <input type="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>" readonly style="opacity: 0.6; cursor: not-allowed;">
                    </div>
                    
                    <div class="form-group">
                        <label for="phone">Phone Number</label>
                        <input type="text" name="phone" id="phone" class="form-control" value="<?= htmlspecialchars($user['phone']) ?>" required>
                        <?php if (isset($errors['phone'])): ?>
                            <span style="color: var(--danger-color); font-size: 0.8rem;"><?= $errors['phone'] ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <button type="submit" name="update_profile" class="btn btn-primary" style="border-radius: 8px; margin-top: 1rem;">
                        <i class="fas fa-save"></i> Save Changes
                    </button>
                </form>
            </div>

            <!-- Password Change Form -->
            <div id="change-password" class="card-form" style="text-align: left; box-shadow: none;">
                <h3 style="text-align: left; font-size: 1.25rem; border-bottom: 1px solid var(--border-color); padding-bottom: 0.75rem; margin-bottom: 1.5rem;">Change Password</h3>
                
                <?php if (isset($pw_errors['db'])): ?>
                    <div class="alert alert-danger"><?= $pw_errors['db'] ?></div>
                <?php endif; ?>
                
                <form method="POST" action="profile.php#change-password">
                    <div class="form-group">
                        <label for="current_password">Current Password</label>
                        <input type="password" name="current_password" id="current_password" class="form-control" placeholder="Enter current password" required>
                        <?php if (isset($pw_errors['current'])): ?>
                            <span style="color: var(--danger-color); font-size: 0.8rem;"><?= $pw_errors['current'] ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group">
                        <label for="new_password">New Password</label>
                        <input type="password" name="new_password" id="new_password" class="form-control" placeholder="Min. 6 characters" required>
                        <?php if (isset($pw_errors['new'])): ?>
                            <span style="color: var(--danger-color); font-size: 0.8rem;"><?= $pw_errors['new'] ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm_new_password">Confirm New Password</label>
                        <input type="password" name="confirm_new_password" id="confirm_new_password" class="form-control" placeholder="Repeat new password" required>
                        <?php if (isset($pw_errors['confirm'])): ?>
                            <span style="color: var(--danger-color); font-size: 0.8rem;"><?= $pw_errors['confirm'] ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <button type="submit" name="change_password" class="btn btn-primary" style="border-radius: 8px; margin-top: 1rem;">
                        <i class="fas fa-key"></i> Update Password
                    </button>
                </form>
            </div>
        </div>
    </main>
</div>

<?php require_once 'includes/footer.php'; ?>
