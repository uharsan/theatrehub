<?php
$page_title = "Movies";
$active_page = "features";
$base_path = "./";
require_once 'includes/config.php';

// Helper to get image sources
function get_movie_image($image) {
    $local_path = 'assets/images/' . $image;
    if (file_exists($local_path) && !is_dir($local_path)) {
        return $local_path;
    }
    
    // Premium Unsplash fallback image mappings
    $fallbacks = [
        'kalki.jpg' => 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=500&q=80',
        'leo.jpg' => 'https://images.unsplash.com/photo-1546182990-dffeafbe841d?auto=format&fit=crop&w=500&q=80',
        'goat.jpg' => 'https://images.unsplash.com/photo-1506318137071-a8e063b4bec0?auto=format&fit=crop&w=500&q=80',
        'jailer.jpg' => 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&w=500&q=80',
        'devara.jpg' => 'https://images.unsplash.com/photo-1505118380757-91f5f5632de0?auto=format&fit=crop&w=500&q=80',
        'vettaiyan.jpg' => 'https://images.unsplash.com/photo-1453873531674-215110190687?auto=format&fit=crop&w=500&q=80',
        'dune2.jpg' => 'https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?auto=format&fit=crop&w=500&q=80',
        'maharaja.jpg' => 'https://images.unsplash.com/photo-1503951914875-452162b0f3f1?auto=format&fit=crop&w=500&q=80',
        'kanguva.jpg' => 'https://images.unsplash.com/photo-1533105079780-92b9be482077?auto=format&fit=crop&w=500&q=80',
        'amaran.jpg' => 'https://images.unsplash.com/photo-1508962914676-134849a727f0?auto=format&fit=crop&w=500&q=80'
    ];
    
    return isset($fallbacks[$image]) ? $fallbacks[$image] : 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=500&q=80';
}

// Handle Movie Booking
if (isset($_POST['book_movie'])) {
    if (!isset($_SESSION['user_id'])) {
        $_SESSION['error'] = "Please login first to book tickets.";
        header("Location: login.php");
        exit();
    }
    
    $user_id = $_SESSION['user_id'];
    $movie_name = sanitize_input($_POST['movie_name']);
    
    try {
        // Confirm movie exists
        $chk_stmt = $pdo->prepare("SELECT * FROM `features` WHERE `features_name` = ?");
        $chk_stmt->execute([$movie_name]);
        if ($chk_stmt->rowCount() > 0) {
            // Book the movie in 'add' table
            $book_stmt = $pdo->prepare("INSERT INTO `add` (`user_id`, `features_name`, `status`) VALUES (?, ?, ?)");
            $book_stmt->execute([$user_id, $movie_name, 'Upcoming']);
            $_SESSION['success'] = "Successfully booked tickets for " . htmlspecialchars($movie_name) . "!";
            header("Location: dashboard.php");
            exit();
        } else {
            $_SESSION['error'] = "Selected movie is not available.";
        }
    } catch (PDOException $e) {
        $_SESSION['error'] = "Booking failed: " . $e->getMessage();
    }
}

// Fetch Movies with Search Filtering
$search = isset($_GET['search']) ? sanitize_input($_GET['search']) : '';
try {
    if ($search !== '') {
        $stmt = $pdo->prepare("SELECT * FROM `features` WHERE `features_name` LIKE ? ORDER BY `created_at` DESC");
        $stmt->execute(['%' . $search . '%']);
    } else {
        $stmt = $pdo->query("SELECT * FROM `features` ORDER BY `created_at` DESC");
    }
    $movies = $stmt->fetchAll();
} catch (PDOException $e) {
    $movies = [];
}

require_once 'includes/header.php';
?>

<section>
    <div class="section-title" style="text-align: center; margin-bottom: 2rem;">
        <h2>Now Showing Movies</h2>
        <p>Browse through our collection and book your ticket now</p>
    </div>
    
    <!-- Search Bar -->
    <div class="search-bar">
        <form method="GET" action="features.php">
            <div class="search-input-group">
                <input type="text" name="search" id="search" class="form-control" placeholder="Search movies..." value="<?= htmlspecialchars($search) ?>">
                <button type="submit" class="search-btn" aria-label="Search">
                    <i class="fas fa-search"></i>
                </button>
            </div>
        </form>
    </div>
    
    <!-- Movies Grid -->
    <div class="grid-cards">
        <?php if (!empty($movies)): ?>
            <?php foreach ($movies as $movie): ?>
                <div class="movie-card">
                    <div class="movie-poster">
                        <img src="<?= get_movie_image($movie['image']) ?>" alt="<?= htmlspecialchars($movie['features_name']) ?>">
                        <span class="movie-badge"><i class="fas fa-star"></i> 4.8</span>
                    </div>
                    <div class="movie-info">
                        <h3 class="movie-title"><?= htmlspecialchars($movie['features_name']) ?></h3>
                        <div class="movie-meta">
                            <span><i class="fas fa-film"></i> Action / Thriller</span>
                            <span><i class="fas fa-clock"></i> 2h 45m</span>
                        </div>
                        <p class="movie-desc"><?= htmlspecialchars($movie['description']) ?></p>
                        <div class="movie-facilities">
                            <i class="fas fa-cogs"></i> <?= htmlspecialchars($movie['facilities']) ?>
                        </div>
                        
                        <form method="POST" action="">
                            <input type="hidden" name="movie_name" value="<?= htmlspecialchars($movie['features_name']) ?>">
                            <button type="submit" name="book_movie" class="btn btn-primary" style="width: 100%;">
                                <i class="fas fa-ticket-alt"></i> Book Now
                            </button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div style="grid-column: 1/-1; text-align: center; padding: 4rem; background-color: var(--bg-secondary); border-radius: var(--border-radius); border: 1px solid var(--border-color);">
                <i class="fas fa-search-minus" style="font-size: 2.5rem; color: var(--primary-color); margin-bottom: 1rem;"></i>
                <h3>No Movies Found</h3>
                <p style="color: var(--text-secondary); margin-top: 0.5rem;">We couldn't find any movies matching "<?= htmlspecialchars($search) ?>". Try searching for something else!</p>
                <a href="features.php" class="btn btn-primary" style="margin-top: 1.5rem;">View All Movies</a>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
