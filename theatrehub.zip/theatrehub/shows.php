<?php
require_once 'includes/config.php';
if(!isset($_SESSION['user_id'])){ header("Location: login.php"); exit(); }

$movie_id = $_GET['movie_id'] ?? 0;

// Movie name eduka
$stmt = $pdo->prepare("SELECT title FROM movies WHERE movie_id = ?");
$stmt->execute([$movie_id]);
$movie = $stmt->fetch();
if(!$movie){ die("Movie not found"); }

// Show times eduka
$stmt = $pdo->prepare("SELECT * FROM shows WHERE movie_id = ? ORDER BY show_date, show_time");
$stmt->execute([$movie_id]);
$shows = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Shows - <?= htmlspecialchars($movie['title']) ?></title>
    <style>
        body { font-family: Arial; padding: 20px; background: #f5f5f5; }
       .show-card { background: white; border: 1px solid #ddd; padding: 20px; margin: 10px; border-radius: 8px; display: inline-block; width: 200px; text-align: center; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
       .btn { background: #007bff; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px; display: inline-block; margin-top: 10px; }
       .btn:hover { background: #0056b3; }
    </style>
</head>
<body>
    <h1>Select Show Time</h1>
    <h2>Movie: <?= htmlspecialchars($movie['title']) ?></h2>
    <a href="movies.php">← Back to Movies</a><br><br>

    <?php if(empty($shows)): ?>
        <p><b>No shows available for this movie bro!</b> <br>phpMyAdmin la `shows` table la data podu.</p>
    <?php else: ?>
        <?php foreach($shows as $s): ?>
        <div class="show-card">
            <h3><?= date('d M Y', strtotime($s['show_date'])) ?></h3>
            <p><b>Time:</b> <?= date('h:i A', strtotime($s['show_time'])) ?></p>
            <p><b>Screen:</b> <?= htmlspecialchars($s['screen_name']) ?></p>
            <a class="btn" href="seat_selection.php?show_id=<?= $s['show_id'] ?>">Select Seats</a>
        </div>
        <?php endforeach; ?>
    <?php endif; ?>
</body>
</html>