-- Create database if not exists
CREATE DATABASE IF NOT EXISTS `theatrehub`;
USE `theatrehub`;

-- Table 1: users
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` INT AUTO_INCREMENT PRIMARY KEY,
  `fullname` VARCHAR(255) NOT NULL,
  `email` VARCHAR(255) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `role` VARCHAR(50) NOT NULL DEFAULT 'user',
  `phone` VARCHAR(50) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table 2: features (movies)
CREATE TABLE IF NOT EXISTS `features` (
  `features_id` INT AUTO_INCREMENT PRIMARY KEY,
  `features_name` VARCHAR(255) NOT NULL UNIQUE,
  `description` TEXT NOT NULL,
  `facilities` VARCHAR(255) NOT NULL,
  `user` VARCHAR(255) NOT NULL,
  `image` VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table 3: add (bookings)
CREATE TABLE IF NOT EXISTS `add` (
  `add_id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `features_name` VARCHAR(255) NOT NULL,
  `status` VARCHAR(50) NOT NULL,
  FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  FOREIGN KEY (`features_name`) REFERENCES `features` (`features_name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Hashed password for 'password123': $2y$10$8w/8V1uF.Q8Q0c9e6n/7u.E1XF/7kP.L7B9e.5Q5w8U0a7X0R7oO6
-- Insert sample users (10 minimum)
INSERT INTO `users` (`user_id`, `fullname`, `email`, `password`, `role`, `phone`, `created_at`) VALUES
(1, 'John Doe', 'john@theatrehub.com', '$2y$10$8w/8V1uF.Q8Q0c9e6n/7u.E1XF/7kP.L7B9e.5Q5w8U0a7X0R7oO6', 'user', '+91 98765 43210', '2026-06-01 10:00:00'),
(2, 'Jane Smith', 'jane@theatrehub.com', '$2y$10$8w/8V1uF.Q8Q0c9e6n/7u.E1XF/7kP.L7B9e.5Q5w8U0a7X0R7oO6', 'user', '+91 98765 43211', '2026-06-01 11:30:00'),
(3, 'Admin User', 'admin@theatrehub.com', '$2y$10$8w/8V1uF.Q8Q0c9e6n/7u.E1XF/7kP.L7B9e.5Q5w8U0a7X0R7oO6', 'admin', '+91 98765 43212', '2026-06-01 09:00:00'),
(4, 'Michael Brown', 'michael@theatrehub.com', '$2y$10$8w/8V1uF.Q8Q0c9e6n/7u.E1XF/7kP.L7B9e.5Q5w8U0a7X0R7oO6', 'admin', '+91 98765 43213', '2026-06-02 14:15:00'),
(5, 'Emily Davis', 'emily@theatrehub.com', '$2y$10$8w/8V1uF.Q8Q0c9e6n/7u.E1XF/7kP.L7B9e.5Q5w8U0a7X0R7oO6', 'user', '+91 98765 43214', '2026-06-02 16:40:00'),
(6, 'David Wilson', 'david@theatrehub.com', '$2y$10$8w/8V1uF.Q8Q0c9e6n/7u.E1XF/7kP.L7B9e.5Q5w8U0a7X0R7oO6', 'user', '+91 98765 43215', '2026-06-03 10:20:00'),
(7, 'Sarah Martinez', 'sarah@theatrehub.com', '$2y$10$8w/8V1uF.Q8Q0c9e6n/7u.E1XF/7kP.L7B9e.5Q5w8U0a7X0R7oO6', 'user', '+91 98765 43216', '2026-06-03 12:05:00'),
(8, 'James Taylor', 'james@theatrehub.com', '$2y$10$8w/8V1uF.Q8Q0c9e6n/7u.E1XF/7kP.L7B9e.5Q5w8U0a7X0R7oO6', 'user', '+91 98765 43217', '2026-06-04 09:10:00'),
(9, 'Linda Anderson', 'linda@theatrehub.com', '$2y$10$8w/8V1uF.Q8Q0c9e6n/7u.E1XF/7kP.L7B9e.5Q5w8U0a7X0R7oO6', 'user', '+91 98765 43218', '2026-06-04 15:55:00'),
(10, 'Robert Thomas', 'robert@theatrehub.com', '$2y$10$8w/8V1uF.Q8Q0c9e6n/7u.E1XF/7kP.L7B9e.5Q5w8U0a7X0R7oO6', 'user', '+91 98765 43219', '2026-06-05 11:45:00');

-- Insert sample features (movies) (10 minimum)
INSERT INTO `features` (`features_id`, `features_name`, `description`, `facilities`, `user`, `image`, `created_at`) VALUES
(1, 'Kalki 2898 AD', 'A sci-fi epic movie set in a post-apocalyptic world following a modern-day avatar of Vishnu.', 'Dolby Atmos, IMAX 3D, Recliner Seats', 'admin@theatrehub.com', 'kalki.jpg', '2026-06-01 10:00:00'),
(2, 'Leo', 'An action-packed thriller centering around a mild-mannered cafe owner who is suspected of being a former gang leader.', 'Dolby Atmos, 4K Projection, Premium Seats', 'admin@theatrehub.com', 'leo.jpg', '2026-06-01 11:00:00'),
(3, 'GOAT', 'A high-octane spy action thriller tracking elite agents facing threats from their own past.', 'Dolby Atmos, 4K Projection, Recliner Seats', 'admin@theatrehub.com', 'goat.jpg', '2026-06-01 12:00:00'),
(4, 'Jailer', 'A retired prison warden goes on a ruthless manhunt to rescue his son from a powerful smuggler.', 'Dolby Atmos, 2D Digital, VIP Box', 'admin@theatrehub.com', 'jailer.jpg', '2026-06-01 13:00:00'),
(5, 'Devara', 'An epic action saga set across coastal lands charting the lives of fearless warriors protecting their home.', 'Dolby Atmos, IMAX 2D, Recliner Seats', 'admin@theatrehub.com', 'devara.jpg', '2026-06-02 09:00:00'),
(6, 'Vettaiyan', 'A fierce battle for justice led by a dedicated senior police officer uncovering system-wide scams.', 'IMAX 2D, Dolby Atmos, VIP Lounge', 'admin@theatrehub.com', 'vettaiyan.jpg', '2026-06-02 10:00:00'),
(7, 'Dune 2', 'Paul Atreides unites with the Fremen people to seek revenge against the conspirators who destroyed his family.', 'IMAX 3D, Dolby Atmos, Recliner Seats', 'admin@theatrehub.com', 'dune2.jpg', '2026-06-02 11:00:00'),
(8, 'Maharaja', 'A quiet barber seeks vengeance after his home is burgled, leaving the police baffled by what was stolen.', 'Dolby Atmos, 2D Digital, Standard Seats', 'admin@theatrehub.com', 'maharaja.jpg', '2026-06-02 12:00:00'),
(9, 'Kanguva', 'A historic warrior saga bridging timelines to fulfill a promise made centuries ago.', 'Dolby Atmos, 3D Digital, Recliner Seats', 'admin@theatrehub.com', 'kanguva.jpg', '2026-06-03 09:00:00'),
(10, 'Amaran', 'The heroic story of Major Mukund Varadarajan, depicting his ultimate sacrifice for the nation.', 'Dolby Atmos, 2D Digital, Recliner Seats', 'admin@theatrehub.com', 'amaran.jpg', '2026-06-03 10:00:00');

-- Insert sample records into 'add' (bookings) (10 minimum)
INSERT INTO `add` (`add_id`, `user_id`, `features_name`, `status`) VALUES
(1, 1, 'Kalki 2898 AD', 'Upcoming'),
(2, 1, 'Leo', 'Upcoming'),
(3, 1, 'Jailer', 'Completed'),
(4, 2, 'Kalki 2898 AD', 'Upcoming'),
(5, 2, 'GOAT', 'Upcoming'),
(6, 2, 'Jailer', 'Completed'),
(7, 5, 'Devara', 'Upcoming'),
(8, 5, 'Vettaiyan', 'Completed'),
(9, 6, 'Dune 2', 'Upcoming'),
(10, 7, 'Maharaja', 'Completed');
