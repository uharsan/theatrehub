<?php
// delete_user.php - Securely deletes a user by ID with safety guards
require_once '../includes/config.php';

// Admin access guard
require_admin();

// Validate the user ID from URL
$id = filter_var($_GET['id'] ?? 0, FILTER_VALIDATE_INT);
if (!$id) {
    $_SESSION['error'] = "Invalid user ID.";
    header("Location: manage_user.php");
    exit();
}

// Guard: Prevent admin from deleting themselves
if ($id == $_SESSION['user_id']) {
    $_SESSION['error'] = "You cannot delete your own account.";
    header("Location: manage_user.php");
    exit();
}

try {
    // Fetch the user to get their name and role
    $stmt = $pdo->prepare("SELECT `fullname`, `role` FROM `users` WHERE `user_id` = ?");
    $stmt->execute([$id]);
    $user = $stmt->fetch();

    if (!$user) {
        $_SESSION['error'] = "User not found.";
        header("Location: manage_user.php");
        exit();
    }

    // Guard: Prevent deleting the last admin
    if ($user['role'] === 'admin') {
        $admin_count = $pdo->query("SELECT COUNT(*) FROM `users` WHERE `role` = 'admin'")->fetchColumn();
        if ($admin_count <= 1) {
            $_SESSION['error'] = "Cannot delete the last admin account. Promote another user to admin first.";
            header("Location: manage_user.php");
            exit();
        }
    }

    // Delete the user (bookings in `add` table cascade via FK on user_id)
    $del = $pdo->prepare("DELETE FROM `users` WHERE `user_id` = ?");
    $del->execute([$id]);

    $_SESSION['success'] = "User '" . htmlspecialchars($user['fullname']) . "' deleted successfully.";

} catch (PDOException $e) {
    $_SESSION['error'] = "Failed to delete user: " . $e->getMessage();
}

header("Location: manage_user.php");
exit();
?>
