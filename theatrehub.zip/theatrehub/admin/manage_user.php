<?php
// manage_user.php - Admin page to list, search, and manage all registered users
$page_title = "Manage Users";
$active_page = "manage_user";
$base_path = "../";
require_once '../includes/config.php';

// Admin access guard
require_admin();

// Search filter - search by name or email
$search = isset($_GET['search']) ? sanitize_input($_GET['search']) : '';

try {
    if ($search !== '') {
        // Search users by fullname or email using prepared statement
        $stmt = $pdo->prepare("SELECT * FROM `users` WHERE `fullname` LIKE ? OR `email` LIKE ? ORDER BY `created_at` DESC");
        $stmt->execute(['%' . $search . '%', '%' . $search . '%']);
    } else {
        // Fetch all users ordered by newest first
        $stmt = $pdo->query("SELECT * FROM `users` ORDER BY `created_at` DESC");
    }
    $users = $stmt->fetchAll();
} catch (PDOException $e) {
    $_SESSION['error'] = "Failed to fetch users: " . $e->getMessage();
    $users = [];
}

require_once '../includes/header.php';
?>

<div class="dashboard-grid">
    <!-- Admin Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-title">Admin Panel</div>
        <ul class="sidebar-menu">
            <li><a href="admin_dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="manage_features.php"><i class="fas fa-film"></i> Manage Movies</a></li>
            <li><a href="manage_user.php" class="active"><i class="fas fa-users"></i> Manage Users</a></li>
            <li style="border-top: 1px solid var(--border-color); padding-top: 0.5rem; margin-top: 0.5rem;">
                <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </li>
        </ul>
    </aside>

    <!-- Main Content -->
    <main class="dashboard-content">
        <div class="table-container">
            <!-- Header with Add User button -->
            <div class="table-header-row">
                <h3><i class="fas fa-users" style="color: var(--primary-color); margin-right: 8px;"></i> Manage Users</h3>
                <a href="add_user.php" class="btn btn-primary btn-small"><i class="fas fa-plus"></i> Add User</a>
            </div>

            <!-- Search Bar -->
            <div style="padding: 1rem 1.5rem; border-bottom: 1px solid var(--border-color);">
                <form method="GET" action="manage_user.php">
                    <div class="search-input-group" style="max-width: 400px;">
                        <input type="text" name="search" class="form-control" placeholder="Search by name or email..." value="<?= htmlspecialchars($search) ?>">
                        <button type="submit" class="search-btn" aria-label="Search"><i class="fas fa-search"></i></button>
                    </div>
                </form>
            </div>

            <!-- Users Table -->
            <table class="responsive-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Full Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Role</th>
                        <th>Joined</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($users)): ?>
                        <?php foreach ($users as $i => $user): ?>
                            <tr>
                                <td><?= $i + 1 ?></td>
                                <td style="font-weight: 600;"><?= htmlspecialchars($user['fullname']) ?></td>
                                <td style="font-size: 0.85rem;"><?= htmlspecialchars($user['email']) ?></td>
                                <td style="font-size: 0.85rem; color: var(--text-secondary);"><?= htmlspecialchars($user['phone']) ?></td>
                                <td>
                                    <?php if ($user['role'] === 'admin'): ?>
                                        <span class="badge badge-admin">Admin</span>
                                    <?php else: ?>
                                        <span class="badge badge-user">User</span>
                                    <?php endif; ?>
                                </td>
                                <td style="font-size: 0.8rem; color: var(--text-secondary);"><?= date('d M Y', strtotime($user['created_at'])) ?></td>
                                <td>
                                    <div style="display: flex; gap: 8px;">
                                        <!-- Edit User Button -->
                                        <a href="edit_user.php?id=<?= $user['user_id'] ?>" class="btn btn-outline btn-small" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <!-- Delete User Button with confirmation -->
                                        <a href="delete_user.php?id=<?= $user['user_id'] ?>"
                                           class="btn btn-small"
                                           style="background-color: rgba(230,57,70,0.15); color: var(--danger-color); border: 1px solid rgba(230,57,70,0.3); border-radius: 20px; padding: 0.4rem 1rem;"
                                           onclick="return confirm('Are you sure you want to delete user \'<?= htmlspecialchars(addslashes($user['fullname'])) ?>\'? This will also remove all their bookings.');"
                                           title="Delete">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" style="text-align: center; padding: 3rem; color: var(--text-secondary);">
                                <i class="fas fa-users" style="font-size: 2rem; color: var(--primary-color); margin-bottom: 1rem; display: block;"></i>
                                <?php if ($search !== ''): ?>
                                    No users found matching "<strong><?= htmlspecialchars($search) ?></strong>". <a href="manage_user.php" style="color: var(--primary-color);">Clear search</a>.
                                <?php else: ?>
                                    No users found. <a href="add_user.php" style="color: var(--primary-color);">Add the first one</a>!
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<?php require_once '../includes/footer.php'; ?>
