<?php
$page_title = "Edit Movie";
$base_path = "../";
require_once '../includes/config.php';

// Admin access guard
require_admin();

// Validate the feature ID from URL
$id = filter_var($_GET['id'] ?? 0, FILTER_VALIDATE_INT);
if (!$id) {
    $_SESSION['error'] = "Invalid movie ID.";
    header("Location: manage_features.php");
    exit();
}

// Fetch the existing feature
try {
    $stmt = $pdo->prepare("SELECT * FROM `features` WHERE `features_id` = ?");
    $stmt->execute([$id]);
    $movie = $stmt->fetch();
    if (!$movie) {
        $_SESSION['error'] = "Movie not found.";
        header("Location: manage_features.php");
        exit();
    }
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}

$errors = [];

if (isset($_POST['update_feature'])) {
    // Sanitize inputs
    $features_name = sanitize_input($_POST['features_name']);
    $description   = sanitize_input($_POST['description']);
    $facilities    = sanitize_input($_POST['facilities']);

    // Validation
    if (empty($features_name)) $errors['features_name'] = "Movie name is required.";
    if (empty($description))   $errors['description']   = "Description is required.";
    if (empty($facilities))    $errors['facilities']     = "Facilities are required.";

    // Handle optional image replacement
    $image_filename = $movie['image']; // keep existing by default
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $file_type = mime_content_type($_FILES['image']['tmp_name']);

        if (!in_array($file_type, $allowed_types)) {
            $errors['image'] = "Only JPG, PNG, GIF, or WEBP images are allowed.";
        } elseif ($_FILES['image']['size'] > 5 * 1024 * 1024) {
            $errors['image'] = "Image size must not exceed 5MB.";
        } else {
            $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $new_filename = strtolower(str_replace(' ', '_', $features_name)) . '_' . time() . '.' . $ext;
            $upload_dir = '../assets/images/';
            if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
            if (move_uploaded_file($_FILES['image']['tmp_name'], $upload_dir . $new_filename)) {
                // Delete old image if it exists locally and isn't the default
                $old_path = $upload_dir . $movie['image'];
                if ($movie['image'] !== 'default.jpg' && file_exists($old_path)) {
                    unlink($old_path);
                }
                $image_filename = $new_filename;
            }
        }
    }

    if (empty($errors)) {
        try {
            // Check uniqueness (excluding current record)
            $chk = $pdo->prepare("SELECT features_id FROM `features` WHERE `features_name` = ? AND `features_id` != ?");
            $chk->execute([$features_name, $id]);
            if ($chk->rowCount() > 0) {
                $errors['features_name'] = "Another movie with this name already exists.";
            } else {
                $upd = $pdo->prepare("UPDATE `features` SET `features_name` = ?, `description` = ?, `facilities` = ?, `image` = ? WHERE `features_id` = ?");
                $upd->execute([$features_name, $description, $facilities, $image_filename, $id]);
                $_SESSION['success'] = "Movie updated successfully!";
                header("Location: manage_features.php");
                exit();
            }
        } catch (PDOException $e) {
            $errors['db'] = "Database error: " . $e->getMessage();
        }
    }
}

// Use POST values on error, otherwise DB values
$features_name = isset($features_name) ? $features_name : $movie['features_name'];
$description   = isset($description)   ? $description   : $movie['description'];
$facilities    = isset($facilities)    ? $facilities    : $movie['facilities'];

require_once '../includes/header.php';
?>

<div class="dashboard-grid">
    <aside class="sidebar">
        <div class="sidebar-title">Admin Panel</div>
        <ul class="sidebar-menu">
            <li><a href="admin_dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="manage_features.php" class="active"><i class="fas fa-film"></i> Manage Movies</a></li>
            <li><a href="manage_user.php"><i class="fas fa-users"></i> Manage Users</a></li>
            <li style="border-top: 1px solid var(--border-color); padding-top: 0.5rem; margin-top: 0.5rem;">
                <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </li>
        </ul>
    </aside>

    <main class="dashboard-content">
        <div class="card-form" style="text-align: left; max-width: 700px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
                <h3 style="text-align: left;"><i class="fas fa-edit" style="color: var(--primary-color); margin-right: 8px;"></i> Edit Movie</h3>
                <a href="manage_features.php" class="btn btn-outline btn-small"><i class="fas fa-arrow-left"></i> Back</a>
            </div>

            <?php if (isset($errors['db'])): ?>
                <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?= $errors['db'] ?></div>
            <?php endif; ?>

            <form method="POST" action="edit_features.php?id=<?= $id ?>" enctype="multipart/form-data" id="feature-form">
                <div class="form-group">
                    <label for="features_name">Movie Name</label>
                    <input type="text" name="features_name" id="features_name" class="form-control"
                           value="<?= htmlspecialchars($features_name) ?>" required>
                    <?php if (isset($errors['features_name'])): ?>
                        <span style="color: var(--danger-color); font-size: 0.8rem;"><?= $errors['features_name'] ?></span>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea name="description" id="description" class="form-control" rows="4" required><?= htmlspecialchars($description) ?></textarea>
                    <?php if (isset($errors['description'])): ?>
                        <span style="color: var(--danger-color); font-size: 0.8rem;"><?= $errors['description'] ?></span>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="facilities">Facilities / Screening Type</label>
                    <input type="text" name="facilities" id="facilities" class="form-control"
                           value="<?= htmlspecialchars($facilities) ?>" required>
                    <?php if (isset($errors['facilities'])): ?>
                        <span style="color: var(--danger-color); font-size: 0.8rem;"><?= $errors['facilities'] ?></span>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label>Current Poster</label>
                    <div style="margin-bottom: 0.75rem; padding: 0.75rem; background: var(--bg-card); border-radius: 8px; border: 1px solid var(--border-color); display: flex; align-items: center; gap: 1rem;">
                        <i class="fas fa-image" style="color: var(--primary-color); font-size: 1.5rem;"></i>
                        <span style="font-size: 0.85rem; color: var(--text-secondary);"><?= htmlspecialchars($movie['image']) ?></span>
                    </div>
                    <label for="image">Replace Poster (Optional – JPG, PNG, WEBP)</label>
                    <input type="file" name="image" id="image" class="form-control" accept="image/*">
                    <?php if (isset($errors['image'])): ?>
                        <span style="color: var(--danger-color); font-size: 0.8rem;"><?= $errors['image'] ?></span>
                    <?php endif; ?>
                </div>

                <div style="display: flex; gap: 1rem; margin-top: 1.5rem;">
                    <button type="submit" name="update_feature" class="btn btn-primary" style="border-radius: 8px; flex: 1;">
                        <i class="fas fa-save"></i> Update Movie
                    </button>
                    <a href="manage_features.php" class="btn btn-outline" style="border-radius: 8px;">Cancel</a>
                </div>
            </form>
        </div>
    </main>
</div>

<?php require_once '../includes/footer.php'; ?>
