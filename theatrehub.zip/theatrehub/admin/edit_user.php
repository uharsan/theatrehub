<?php
// edit_user.php - Admin form to update an existing user's details
$page_title = "Edit User";
$active_page = "manage_user";
$base_path = "../";
require_once '../includes/config.php';

// Admin access guard
require_admin();

// Validate the user ID from URL
$id = filter_var($_GET['id'] ?? 0, FILTER_VALIDATE_INT);
if (!$id) {
    $_SESSION['error'] = "Invalid user ID.";
    header("Location: manage_user.php");
    exit();
}

// Fetch the existing user data
try {
    $stmt = $pdo->prepare("SELECT * FROM `users` WHERE `user_id` = ?");
    $stmt->execute([$id]);
    $user = $stmt->fetch();
    if (!$user) {
        $_SESSION['error'] = "User not found.";
        header("Location: manage_user.php");
        exit();
    }
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}

$errors = [];

if (isset($_POST['update_user'])) {
    // Sanitize inputs
    $fullname = sanitize_input($_POST['fullname']);
    $phone    = sanitize_input($_POST['phone']);
    $role     = sanitize_input($_POST['role']);
    $password = $_POST['password']; // Optional - only update if filled

    // --- Server-side Validation ---
    if (empty($fullname)) {
        $errors['fullname'] = "Full name is required.";
    } elseif (strlen($fullname) < 2) {
        $errors['fullname'] = "Full name must be at least 2 characters.";
    }

    if (empty($phone)) {
        $errors['phone'] = "Phone number is required.";
    } elseif (!preg_match('/^[0-9+\-\s]{7,20}$/', $phone)) {
        $errors['phone'] = "Please enter a valid phone number.";
    }

    if (!in_array($role, ['user', 'admin'])) {
        $errors['role'] = "Invalid role selected.";
    }

    // If password is provided, validate minimum length
    if (!empty($password) && strlen($password) < 6) {
        $errors['password'] = "Password must be at least 6 characters.";
    }

    // Prevent admin from removing their own admin role
    if ($id == $_SESSION['user_id'] && $role !== 'admin') {
        $errors['role'] = "You cannot remove your own admin privileges.";
    }

    if (empty($errors)) {
        try {
            if (!empty($password)) {
                // Update user WITH new password
                $hashed_password = password_hash($password, PASSWORD_BCRYPT);
                $upd = $pdo->prepare("UPDATE `users` SET `fullname` = ?, `phone` = ?, `role` = ?, `password` = ? WHERE `user_id` = ?");
                $upd->execute([$fullname, $phone, $role, $hashed_password, $id]);
            } else {
                // Update user WITHOUT changing password
                $upd = $pdo->prepare("UPDATE `users` SET `fullname` = ?, `phone` = ?, `role` = ? WHERE `user_id` = ?");
                $upd->execute([$fullname, $phone, $role, $id]);
            }

            $_SESSION['success'] = "User '" . htmlspecialchars($fullname) . "' updated successfully!";
            header("Location: manage_user.php");
            exit();
        } catch (PDOException $e) {
            $errors['db'] = "Database error: " . $e->getMessage();
        }
    }
}

// Use POST values on error, otherwise use DB values
$fullname = isset($fullname) ? $fullname : $user['fullname'];
$phone    = isset($phone)    ? $phone    : $user['phone'];
$role     = isset($role)     ? $role     : $user['role'];

require_once '../includes/header.php';
?>

<div class="dashboard-grid">
    <!-- Admin Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-title">Admin Panel</div>
        <ul class="sidebar-menu">
            <li><a href="admin_dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="manage_features.php"><i class="fas fa-film"></i> Manage Movies</a></li>
            <li><a href="manage_user.php" class="active"><i class="fas fa-users"></i> Manage Users</a></li>
            <li style="border-top: 1px solid var(--border-color); padding-top: 0.5rem; margin-top: 0.5rem;">
                <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </li>
        </ul>
    </aside>

    <!-- Main Content -->
    <main class="dashboard-content">
        <div class="card-form" style="text-align: left; max-width: 700px;">
            <!-- Page Header with Back button -->
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
                <h3 style="text-align: left;"><i class="fas fa-user-edit" style="color: var(--primary-color); margin-right: 8px;"></i> Edit User</h3>
                <a href="manage_user.php" class="btn btn-outline btn-small"><i class="fas fa-arrow-left"></i> Back</a>
            </div>

            <!-- Database error display -->
            <?php if (isset($errors['db'])): ?>
                <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?= $errors['db'] ?></div>
            <?php endif; ?>

            <!-- Edit User Form -->
            <form method="POST" action="edit_user.php?id=<?= $id ?>" id="user-form">
                <!-- Full Name -->
                <div class="form-group">
                    <label for="fullname">Full Name</label>
                    <input type="text" name="fullname" id="fullname" class="form-control"
                           value="<?= htmlspecialchars($fullname) ?>" required>
                    <?php if (isset($errors['fullname'])): ?>
                        <span style="color: var(--danger-color); font-size: 0.8rem;"><?= $errors['fullname'] ?></span>
                    <?php endif; ?>
                </div>

                <!-- Email (Read-only) -->
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <div style="padding: 0.75rem 1rem; background: var(--bg-card); border-radius: 8px; border: 1px solid var(--border-color); display: flex; align-items: center; gap: 0.75rem; color: var(--text-secondary);">
                        <i class="fas fa-envelope" style="color: var(--primary-color);"></i>
                        <span><?= htmlspecialchars($user['email']) ?></span>
                        <span style="margin-left: auto; font-size: 0.75rem; opacity: 0.6;"><i class="fas fa-lock"></i> Cannot be changed</span>
                    </div>
                </div>

                <!-- Phone Number -->
                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="tel" name="phone" id="phone" class="form-control"
                           value="<?= htmlspecialchars($phone) ?>" required>
                    <?php if (isset($errors['phone'])): ?>
                        <span style="color: var(--danger-color); font-size: 0.8rem;"><?= $errors['phone'] ?></span>
                    <?php endif; ?>
                </div>

                <!-- Role Selection -->
                <div class="form-group">
                    <label for="role">Role</label>
                    <select name="role" id="role" class="form-control" required>
                        <option value="user" <?= $role === 'user' ? 'selected' : '' ?>>User</option>
                        <option value="admin" <?= $role === 'admin' ? 'selected' : '' ?>>Admin</option>
                    </select>
                    <?php if (isset($errors['role'])): ?>
                        <span style="color: var(--danger-color); font-size: 0.8rem;"><?= $errors['role'] ?></span>
                    <?php endif; ?>
                </div>

                <!-- Password Reset (Optional) -->
                <div class="form-group">
                    <label for="password">Reset Password <span style="font-weight: 400; font-size: 0.8rem; color: var(--text-secondary);">(Leave blank to keep current password)</span></label>
                    <input type="password" name="password" id="password" class="form-control"
                           placeholder="Enter new password (min 6 characters)">
                    <?php if (isset($errors['password'])): ?>
                        <span style="color: var(--danger-color); font-size: 0.8rem;"><?= $errors['password'] ?></span>
                    <?php endif; ?>
                </div>

                <!-- User Info Card -->
                <div style="padding: 1rem 1.25rem; background: var(--bg-card); border-radius: 8px; border: 1px solid var(--border-color); margin-bottom: 1rem;">
                    <div style="font-size: 0.8rem; color: var(--text-secondary); display: flex; justify-content: space-between; flex-wrap: wrap; gap: 0.5rem;">
                        <span><i class="fas fa-calendar-alt" style="color: var(--primary-color); margin-right: 4px;"></i> Joined: <?= date('d M Y, h:i A', strtotime($user['created_at'])) ?></span>
                        <span><i class="fas fa-id-badge" style="color: var(--primary-color); margin-right: 4px;"></i> User ID: #<?= str_pad($user['user_id'], 4, '0', STR_PAD_LEFT) ?></span>
                    </div>
                </div>

                <!-- Action Buttons -->
                <div style="display: flex; gap: 1rem; margin-top: 1.5rem;">
                    <button type="submit" name="update_user" class="btn btn-primary" style="border-radius: 8px; flex: 1;">
                        <i class="fas fa-save"></i> Update User
                    </button>
                    <a href="manage_user.php" class="btn btn-outline" style="border-radius: 8px;">Cancel</a>
                </div>
            </form>
        </div>
    </main>
</div>

<!-- Client-side validation for optional password -->
<script>
document.getElementById('user-form').addEventListener('submit', function(e) {
    const password = document.getElementById('password').value;

    // Only validate password if it's been filled in
    if (password.length > 0 && password.length < 6) {
        e.preventDefault();
        alert('Password must be at least 6 characters long.');
        return;
    }
});
</script>

<?php require_once '../includes/footer.php'; ?>
