<?php
// delete_features.php - Securely deletes a movie/feature by ID
require_once '../includes/config.php';

// Admin access guard
require_admin();

// Validate ID
$id = filter_var($_GET['id'] ?? 0, FILTER_VALIDATE_INT);
if (!$id) {
    $_SESSION['error'] = "Invalid movie ID.";
    header("Location: manage_features.php");
    exit();
}

try {
    // Fetch the feature first to get image filename for deletion
    $stmt = $pdo->prepare("SELECT `image`, `features_name` FROM `features` WHERE `features_id` = ?");
    $stmt->execute([$id]);
    $movie = $stmt->fetch();

    if (!$movie) {
        $_SESSION['error'] = "Movie not found.";
        header("Location: manage_features.php");
        exit();
    }

    // Delete the feature (cascades to bookings in `add` table via FK)
    $del_stmt = $pdo->prepare("DELETE FROM `features` WHERE `features_id` = ?");
    $del_stmt->execute([$id]);

    // Remove uploaded image file if it exists locally
    $image_path = '../assets/images/' . $movie['image'];
    if ($movie['image'] !== 'default.jpg' && file_exists($image_path)) {
        unlink($image_path);
    }

    $_SESSION['success'] = "Movie '" . htmlspecialchars($movie['features_name']) . "' deleted successfully.";

} catch (PDOException $e) {
    $_SESSION['error'] = "Failed to delete movie: " . $e->getMessage();
}

header("Location: manage_features.php");
exit();
?>
