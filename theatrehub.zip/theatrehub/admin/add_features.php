<?php
$page_title = "Add Movie";
$base_path = "../";
require_once '../includes/config.php';

// Admin access guard
require_admin();

$errors = [];

if (isset($_POST['add_feature'])) {
    // Sanitize inputs
    $features_name = sanitize_input($_POST['features_name']);
    $description   = sanitize_input($_POST['description']);
    $facilities    = sanitize_input($_POST['facilities']);
    $user          = $_SESSION['email'];

    // Validation
    if (empty($features_name)) $errors['features_name'] = "Movie name is required.";
    if (empty($description))   $errors['description']   = "Description is required.";
    if (empty($facilities))    $errors['facilities']     = "Facilities are required.";

    // Image upload handling
    $image_filename = 'default.jpg';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $file_type = mime_content_type($_FILES['image']['tmp_name']);

        if (!in_array($file_type, $allowed_types)) {
            $errors['image'] = "Only JPG, PNG, GIF, or WEBP images are allowed.";
        } elseif ($_FILES['image']['size'] > 5 * 1024 * 1024) {
            $errors['image'] = "Image size must not exceed 5MB.";
        } else {
            $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $image_filename = strtolower(str_replace(' ', '_', $features_name)) . '_' . time() . '.' . $ext;
            $upload_dir = '../assets/images/';
            if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
            move_uploaded_file($_FILES['image']['tmp_name'], $upload_dir . $image_filename);
        }
    } elseif (isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
        $errors['image'] = "Image upload failed. Please try again.";
    }

    if (empty($errors)) {
        try {
            // Check uniqueness
            $chk = $pdo->prepare("SELECT features_id FROM `features` WHERE `features_name` = ?");
            $chk->execute([$features_name]);
            if ($chk->rowCount() > 0) {
                $errors['features_name'] = "A movie with this name already exists.";
            } else {
                $stmt = $pdo->prepare("INSERT INTO `features` (`features_name`, `description`, `facilities`, `user`, `image`) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$features_name, $description, $facilities, $user, $image_filename]);
                $_SESSION['success'] = "Movie '" . htmlspecialchars($features_name) . "' added successfully!";
                header("Location: manage_features.php");
                exit();
            }
        } catch (PDOException $e) {
            $errors['db'] = "Database error: " . $e->getMessage();
        }
    }
}

require_once '../includes/header.php';
?>

<div class="dashboard-grid">
    <aside class="sidebar">
        <div class="sidebar-title">Admin Panel</div>
        <ul class="sidebar-menu">
            <li><a href="admin_dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="manage_features.php" class="active"><i class="fas fa-film"></i> Manage Movies</a></li>
            <li><a href="manage_user.php"><i class="fas fa-users"></i> Manage Users</a></li>
            <li style="border-top: 1px solid var(--border-color); padding-top: 0.5rem; margin-top: 0.5rem;">
                <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </li>
        </ul>
    </aside>

    <main class="dashboard-content">
        <div class="card-form" style="text-align: left; max-width: 700px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
                <h3 style="text-align: left;"><i class="fas fa-plus-circle" style="color: var(--primary-color); margin-right: 8px;"></i> Add New Movie</h3>
                <a href="manage_features.php" class="btn btn-outline btn-small"><i class="fas fa-arrow-left"></i> Back</a>
            </div>

            <?php if (isset($errors['db'])): ?>
                <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?= $errors['db'] ?></div>
            <?php endif; ?>

            <form method="POST" action="add_features.php" enctype="multipart/form-data" id="feature-form">
                <div class="form-group">
                    <label for="features_name">Movie Name</label>
                    <input type="text" name="features_name" id="features_name" class="form-control"
                           placeholder="e.g. Kalki 2898 AD"
                           value="<?= isset($features_name) ? htmlspecialchars($features_name) : '' ?>" required>
                    <?php if (isset($errors['features_name'])): ?>
                        <span style="color: var(--danger-color); font-size: 0.8rem;"><?= $errors['features_name'] ?></span>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea name="description" id="description" class="form-control" rows="4"
                              placeholder="Brief description of the movie..." required><?= isset($description) ? htmlspecialchars($description) : '' ?></textarea>
                    <?php if (isset($errors['description'])): ?>
                        <span style="color: var(--danger-color); font-size: 0.8rem;"><?= $errors['description'] ?></span>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="facilities">Facilities / Screening Type</label>
                    <input type="text" name="facilities" id="facilities" class="form-control"
                           placeholder="e.g. Dolby Atmos, IMAX 3D, Recliner Seats"
                           value="<?= isset($facilities) ? htmlspecialchars($facilities) : '' ?>" required>
                    <?php if (isset($errors['facilities'])): ?>
                        <span style="color: var(--danger-color); font-size: 0.8rem;"><?= $errors['facilities'] ?></span>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="image">Movie Poster Image (JPG, PNG, WEBP – Max 5MB)</label>
                    <input type="file" name="image" id="image" class="form-control" accept="image/*" required>
                    <?php if (isset($errors['image'])): ?>
                        <span style="color: var(--danger-color); font-size: 0.8rem;"><?= $errors['image'] ?></span>
                    <?php endif; ?>
                </div>

                <div style="display: flex; gap: 1rem; margin-top: 1.5rem;">
                    <button type="submit" name="add_feature" class="btn btn-primary" style="border-radius: 8px; flex: 1;">
                        <i class="fas fa-save"></i> Save Movie
                    </button>
                    <a href="manage_features.php" class="btn btn-outline" style="border-radius: 8px;">Cancel</a>
                </div>
            </form>
        </div>
    </main>
</div>

<?php require_once '../includes/footer.php'; ?>
