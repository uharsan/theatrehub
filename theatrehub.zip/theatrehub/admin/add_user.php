<?php
// add_user.php - Admin form to create a new user account
$page_title = "Add User";
$active_page = "manage_user";
$base_path = "../";
require_once '../includes/config.php';

// Admin access guard
require_admin();

$errors = [];

if (isset($_POST['add_user'])) {
    // Sanitize inputs
    $fullname         = sanitize_input($_POST['fullname']);
    $email            = sanitize_input($_POST['email']);
    $phone            = sanitize_input($_POST['phone']);
    $password         = $_POST['password'];         // Don't sanitize password (hashing handles it)
    $confirm_password = $_POST['confirm_password'];
    $role             = sanitize_input($_POST['role']);

    // --- Server-side Validation ---
    if (empty($fullname)) {
        $errors['fullname'] = "Full name is required.";
    } elseif (strlen($fullname) < 2) {
        $errors['fullname'] = "Full name must be at least 2 characters.";
    }

    if (empty($email)) {
        $errors['email'] = "Email address is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = "Please enter a valid email address.";
    }

    if (empty($phone)) {
        $errors['phone'] = "Phone number is required.";
    } elseif (!preg_match('/^[0-9+\-\s]{7,20}$/', $phone)) {
        $errors['phone'] = "Please enter a valid phone number.";
    }

    if (empty($password)) {
        $errors['password'] = "Password is required.";
    } elseif (strlen($password) < 6) {
        $errors['password'] = "Password must be at least 6 characters.";
    }

    if ($password !== $confirm_password) {
        $errors['confirm_password'] = "Passwords do not match.";
    }

    if (!in_array($role, ['user', 'admin'])) {
        $errors['role'] = "Invalid role selected.";
    }

    // If no validation errors, proceed to insert
    if (empty($errors)) {
        try {
            // Check if email already exists
            $chk = $pdo->prepare("SELECT user_id FROM `users` WHERE `email` = ?");
            $chk->execute([$email]);
            if ($chk->rowCount() > 0) {
                $errors['email'] = "A user with this email already exists.";
            } else {
                // Hash password securely
                $hashed_password = password_hash($password, PASSWORD_BCRYPT);

                // Insert new user
                $stmt = $pdo->prepare("INSERT INTO `users` (`fullname`, `email`, `phone`, `password`, `role`) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$fullname, $email, $phone, $hashed_password, $role]);

                $_SESSION['success'] = "User '" . htmlspecialchars($fullname) . "' created successfully!";
                header("Location: manage_user.php");
                exit();
            }
        } catch (PDOException $e) {
            $errors['db'] = "Database error: " . $e->getMessage();
        }
    }
}

require_once '../includes/header.php';
?>

<div class="dashboard-grid">
    <!-- Admin Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-title">Admin Panel</div>
        <ul class="sidebar-menu">
            <li><a href="admin_dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="manage_features.php"><i class="fas fa-film"></i> Manage Movies</a></li>
            <li><a href="manage_user.php" class="active"><i class="fas fa-users"></i> Manage Users</a></li>
            <li style="border-top: 1px solid var(--border-color); padding-top: 0.5rem; margin-top: 0.5rem;">
                <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </li>
        </ul>
    </aside>

    <!-- Main Content -->
    <main class="dashboard-content">
        <div class="card-form" style="text-align: left; max-width: 700px;">
            <!-- Page Header with Back button -->
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
                <h3 style="text-align: left;"><i class="fas fa-user-plus" style="color: var(--primary-color); margin-right: 8px;"></i> Add New User</h3>
                <a href="manage_user.php" class="btn btn-outline btn-small"><i class="fas fa-arrow-left"></i> Back</a>
            </div>

            <!-- Database error display -->
            <?php if (isset($errors['db'])): ?>
                <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?= $errors['db'] ?></div>
            <?php endif; ?>

            <!-- Add User Form -->
            <form method="POST" action="add_user.php" id="user-form">
                <!-- Full Name -->
                <div class="form-group">
                    <label for="fullname">Full Name</label>
                    <input type="text" name="fullname" id="fullname" class="form-control"
                           placeholder="e.g. John Doe"
                           value="<?= isset($fullname) ? htmlspecialchars($fullname) : '' ?>" required>
                    <?php if (isset($errors['fullname'])): ?>
                        <span style="color: var(--danger-color); font-size: 0.8rem;"><?= $errors['fullname'] ?></span>
                    <?php endif; ?>
                </div>

                <!-- Email Address -->
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" name="email" id="email" class="form-control"
                           placeholder="e.g. john@example.com"
                           value="<?= isset($email) ? htmlspecialchars($email) : '' ?>" required>
                    <?php if (isset($errors['email'])): ?>
                        <span style="color: var(--danger-color); font-size: 0.8rem;"><?= $errors['email'] ?></span>
                    <?php endif; ?>
                </div>

                <!-- Phone Number -->
                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="tel" name="phone" id="phone" class="form-control"
                           placeholder="e.g. +94 77 123 4567"
                           value="<?= isset($phone) ? htmlspecialchars($phone) : '' ?>" required>
                    <?php if (isset($errors['phone'])): ?>
                        <span style="color: var(--danger-color); font-size: 0.8rem;"><?= $errors['phone'] ?></span>
                    <?php endif; ?>
                </div>

                <!-- Password -->
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" name="password" id="password" class="form-control"
                           placeholder="Minimum 6 characters" required>
                    <?php if (isset($errors['password'])): ?>
                        <span style="color: var(--danger-color); font-size: 0.8rem;"><?= $errors['password'] ?></span>
                    <?php endif; ?>
                </div>

                <!-- Confirm Password -->
                <div class="form-group">
                    <label for="confirm_password">Confirm Password</label>
                    <input type="password" name="confirm_password" id="confirm_password" class="form-control"
                           placeholder="Re-enter password" required>
                    <?php if (isset($errors['confirm_password'])): ?>
                        <span style="color: var(--danger-color); font-size: 0.8rem;"><?= $errors['confirm_password'] ?></span>
                    <?php endif; ?>
                </div>

                <!-- Role Selection -->
                <div class="form-group">
                    <label for="role">Role</label>
                    <select name="role" id="role" class="form-control" required>
                        <option value="user" <?= (isset($role) && $role === 'user') ? 'selected' : '' ?>>User</option>
                        <option value="admin" <?= (isset($role) && $role === 'admin') ? 'selected' : '' ?>>Admin</option>
                    </select>
                </div>

                <!-- Action Buttons -->
                <div style="display: flex; gap: 1rem; margin-top: 1.5rem;">
                    <button type="submit" name="add_user" class="btn btn-primary" style="border-radius: 8px; flex: 1;">
                        <i class="fas fa-save"></i> Create User
                    </button>
                    <a href="manage_user.php" class="btn btn-outline" style="border-radius: 8px;">Cancel</a>
                </div>
            </form>
        </div>
    </main>
</div>

<!-- Client-side form validation -->
<script>
document.getElementById('user-form').addEventListener('submit', function(e) {
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm_password').value;
    const email = document.getElementById('email').value;

    // Password length check
    if (password.length < 6) {
        e.preventDefault();
        alert('Password must be at least 6 characters long.');
        return;
    }

    // Password match check
    if (password !== confirmPassword) {
        e.preventDefault();
        alert('Passwords do not match. Please try again.');
        return;
    }

    // Basic email format check
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        e.preventDefault();
        alert('Please enter a valid email address.');
        return;
    }
});
</script>

<?php require_once '../includes/footer.php'; ?>
