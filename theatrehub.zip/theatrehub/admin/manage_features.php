<?php
$page_title = "Manage Movies";
$active_page = "manage_features";
$base_path = "../";
require_once '../includes/config.php';

// Admin access guard
require_admin();

// Search filter
$search = isset($_GET['search']) ? sanitize_input($_GET['search']) : '';

try {
    if ($search !== '') {
        $stmt = $pdo->prepare("SELECT * FROM `features` WHERE `features_name` LIKE ? ORDER BY `created_at` DESC");
        $stmt->execute(['%' . $search . '%']);
    } else {
        $stmt = $pdo->query("SELECT * FROM `features` ORDER BY `created_at` DESC");
    }
    $movies = $stmt->fetchAll();
} catch (PDOException $e) {
    $_SESSION['error'] = "Failed to fetch movies: " . $e->getMessage();
    $movies = [];
}

require_once '../includes/header.php';
?>

<div class="dashboard-grid">
    <aside class="sidebar">
        <div class="sidebar-title">Admin Panel</div>
        <ul class="sidebar-menu">
            <li><a href="admin_dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="manage_features.php" class="active"><i class="fas fa-film"></i> Manage Movies</a></li>
            <li><a href="manage_user.php"><i class="fas fa-users"></i> Manage Users</a></li>
            <li style="border-top: 1px solid var(--border-color); padding-top: 0.5rem; margin-top: 0.5rem;">
                <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </li>
        </ul>
    </aside>

    <main class="dashboard-content">
        <div class="table-container">
            <div class="table-header-row">
                <h3><i class="fas fa-film" style="color: var(--primary-color); margin-right: 8px;"></i> Manage Movies</h3>
                <a href="add_features.php" class="btn btn-primary btn-small"><i class="fas fa-plus"></i> Add Movie</a>
            </div>

            <!-- Search Bar -->
            <div style="padding: 1rem 1.5rem; border-bottom: 1px solid var(--border-color);">
                <form method="GET" action="manage_features.php">
                    <div class="search-input-group" style="max-width: 400px;">
                        <input type="text" name="search" class="form-control" placeholder="Search movies..." value="<?= htmlspecialchars($search) ?>">
                        <button type="submit" class="search-btn" aria-label="Search"><i class="fas fa-search"></i></button>
                    </div>
                </form>
            </div>

            <table class="responsive-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Movie Name</th>
                        <th>Description</th>
                        <th>Facilities</th>
                        <th>Added By</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($movies)): ?>
                        <?php foreach ($movies as $i => $movie): ?>
                            <tr>
                                <td><?= $i + 1 ?></td>
                                <td style="font-weight: 600;"><?= htmlspecialchars($movie['features_name']) ?></td>
                                <td style="max-width: 220px; font-size: 0.8rem; color: var(--text-secondary); overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                                    <?= htmlspecialchars($movie['description']) ?>
                                </td>
                                <td style="font-size: 0.8rem; color: var(--primary-color);"><?= htmlspecialchars($movie['facilities']) ?></td>
                                <td style="font-size: 0.8rem;"><?= htmlspecialchars($movie['user']) ?></td>
                                <td style="font-size: 0.8rem; color: var(--text-secondary);"><?= date('d M Y', strtotime($movie['created_at'])) ?></td>
                                <td>
                                    <div style="display: flex; gap: 8px;">
                                        <a href="edit_features.php?id=<?= $movie['features_id'] ?>" class="btn btn-outline btn-small" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="delete_features.php?id=<?= $movie['features_id'] ?>"
                                           class="btn btn-small"
                                           style="background-color: rgba(230,57,70,0.15); color: var(--danger-color); border: 1px solid rgba(230,57,70,0.3); border-radius: 20px; padding: 0.4rem 1rem;"
                                           onclick="return confirm('Are you sure you want to delete \'<?= htmlspecialchars(addslashes($movie['features_name'])) ?>\'? This will also remove all related bookings.');"
                                           title="Delete">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" style="text-align: center; padding: 3rem; color: var(--text-secondary);">
                                <i class="fas fa-film" style="font-size: 2rem; color: var(--primary-color); margin-bottom: 1rem; display: block;"></i>
                                No movies found. <a href="add_features.php" style="color: var(--primary-color);">Add the first one</a>!
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<?php require_once '../includes/footer.php'; ?>
