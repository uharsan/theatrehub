<?php
$page_title = "Admin Dashboard";
$active_page = "dashboard";
$base_path = "../";
require_once '../includes/config.php';

// Admin access guard
require_admin();

// Fetch overall statistics
try {
    $total_users = $pdo->query("SELECT COUNT(*) FROM `users`")->fetchColumn();
    $total_movies = $pdo->query("SELECT COUNT(*) FROM `features`")->fetchColumn();
    $total_bookings = $pdo->query("SELECT COUNT(*) FROM `add`")->fetchColumn();
    $upcoming_bookings = $pdo->query("SELECT COUNT(*) FROM `add` WHERE `status` = 'Upcoming'")->fetchColumn();
    $completed_bookings = $pdo->query("SELECT COUNT(*) FROM `add` WHERE `status` = 'Completed'")->fetchColumn();
    $cancelled_bookings = $pdo->query("SELECT COUNT(*) FROM `add` WHERE `status` = 'Cancelled'")->fetchColumn();

    // Recent bookings
    $recent_bookings = $pdo->query("
        SELECT a.add_id, u.fullname, a.features_name, a.status
        FROM `add` a
        JOIN `users` u ON a.user_id = u.user_id
        ORDER BY a.add_id DESC
        LIMIT 10
    ")->fetchAll();

    // Recent users
    $recent_users = $pdo->query("
        SELECT user_id, fullname, email, role, created_at
        FROM `users`
        ORDER BY created_at DESC
        LIMIT 5
    ")->fetchAll();

} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}

require_once '../includes/header.php';
?>

<div class="dashboard-grid">
    <!-- Admin Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-title">Admin Panel</div>
        <ul class="sidebar-menu">
            <li><a href="admin_dashboard.php" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="manage_features.php"><i class="fas fa-film"></i> Manage Movies</a></li>
            <li><a href="manage_user.php"><i class="fas fa-users"></i> Manage Users</a></li>
            <li style="border-top: 1px solid var(--border-color); padding-top: 0.5rem; margin-top: 0.5rem;">
                <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </li>
        </ul>
    </aside>

    <!-- Main Content -->
    <main class="dashboard-content">
        <div style="background-color: var(--bg-secondary); border: 1px solid var(--border-color); padding: 1.5rem 2rem; border-radius: var(--border-radius); border-left: 4px solid var(--primary-color);">
            <h2 style="font-family: var(--font-heading);">Admin Dashboard</h2>
            <p style="color: var(--text-secondary); font-size: 0.9rem; margin-top: 0.25rem;">Welcome back, <?= htmlspecialchars($_SESSION['fullname']) ?>. Here's your platform overview.</p>
        </div>

        <!-- Stats Cards -->
        <div class="stats-grid" style="grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));">
            <div class="stat-card">
                <span class="stat-card-title">Total Movies</span>
                <span class="stat-card-value"><?= $total_movies ?></span>
                <span class="stat-card-desc" style="color: var(--text-secondary);">Active features</span>
            </div>
            <div class="stat-card">
                <span class="stat-card-title">Total Users</span>
                <span class="stat-card-value"><?= $total_users ?></span>
                <span class="stat-card-desc">Registered members</span>
            </div>
            <div class="stat-card">
                <span class="stat-card-title">Total Bookings</span>
                <span class="stat-card-value"><?= $total_bookings ?></span>
                <span class="stat-card-desc">All time</span>
            </div>
            <div class="stat-card">
                <span class="stat-card-title">Upcoming</span>
                <span class="stat-card-value" style="color: var(--success-color);"><?= $upcoming_bookings ?></span>
                <span class="stat-card-desc">Active tickets</span>
            </div>
            <div class="stat-card">
                <span class="stat-card-title">Completed</span>
                <span class="stat-card-value" style="color: var(--text-secondary);"><?= $completed_bookings ?></span>
                <span class="stat-card-desc" style="color: var(--text-secondary);">Watched</span>
            </div>
            <div class="stat-card">
                <span class="stat-card-title">Cancelled</span>
                <span class="stat-card-value" style="color: var(--danger-color);"><?= $cancelled_bookings ?></span>
                <span class="stat-card-desc" style="color: var(--danger-color);">Refunded</span>
            </div>
        </div>

        <!-- Charts Row -->
        <div class="charts-grid">
            <!-- Bar Chart: Bookings Breakdown -->
            <div class="chart-card">
                <div class="chart-title">Bookings Overview</div>
                <div class="chart-visual">
                    <?php
                    $max = max($upcoming_bookings, $completed_bookings, $cancelled_bookings, 1);
                    $months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
                    $mock_vals = [40, 65, 45, 80, 55, $total_bookings > 0 ? min($total_bookings * 3, 100) : 70];
                    foreach ($months as $i => $month):
                        $height = ($mock_vals[$i] / 100) * 100;
                    ?>
                        <div style="display: flex; flex-direction: column; align-items: center; gap: 4px; flex: 1; height: 100%;">
                            <div class="bar-chart-bar" data-value="<?= $mock_vals[$i] ?>" style="height: <?= $height ?>%; width: 100%; border-radius: 4px 4px 0 0; background: linear-gradient(to top, var(--primary-color), rgba(230,57,70,0.5));"></div>
                            <span style="font-size: 0.7rem; color: var(--text-secondary);"><?= $month ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Pie Chart: Booking Status Distribution -->
            <div class="chart-card" style="display: flex; flex-direction: column;">
                <div class="chart-title">Bookings by Status</div>
                <div style="display: flex; align-items: center; justify-content: space-around; flex-grow: 1; gap: 1.5rem; flex-wrap: wrap; padding-top: 1rem;">
                    <?php
                    $total = max($total_bookings, 1);
                    $up_pct = round(($upcoming_bookings / $total) * 100);
                    $comp_pct = round(($completed_bookings / $total) * 100);
                    $canc_pct = 100 - $up_pct - $comp_pct;
                    ?>
                    <div class="pie-chart" style="background: conic-gradient(
                        var(--success-color) 0% <?= $up_pct ?>%,
                        var(--text-secondary) <?= $up_pct ?>% <?= $up_pct + $comp_pct ?>%,
                        var(--danger-color) <?= $up_pct + $comp_pct ?>% 100%
                    ); width: 130px; height: 130px;"></div>
                    <div class="pie-chart-legend">
                        <div class="legend-item"><div class="legend-color" style="background: var(--success-color);"></div> Upcoming (<?= $up_pct ?>%)</div>
                        <div class="legend-item"><div class="legend-color" style="background: var(--text-secondary);"></div> Completed (<?= $comp_pct ?>%)</div>
                        <div class="legend-item"><div class="legend-color" style="background: var(--danger-color);"></div> Cancelled (<?= $canc_pct ?>%)</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Bookings Table -->
        <div class="table-container">
            <div class="table-header-row">
                <h3>Recent Bookings</h3>
                <a href="manage_features.php" class="btn btn-primary btn-small"><i class="fas fa-film"></i> Manage Movies</a>
            </div>
            <table class="responsive-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>User</th>
                        <th>Movie</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recent_bookings as $booking): ?>
                        <tr>
                            <td>#<?= str_pad($booking['add_id'], 4, '0', STR_PAD_LEFT) ?></td>
                            <td><?= htmlspecialchars($booking['fullname']) ?></td>
                            <td><?= htmlspecialchars($booking['features_name']) ?></td>
                            <td>
                                <?php
                                $s = strtolower($booking['status']);
                                if ($s === 'upcoming') echo '<span class="badge badge-upcoming">Upcoming</span>';
                                elseif ($s === 'completed') echo '<span class="badge badge-completed">Completed</span>';
                                else echo '<span class="badge badge-cancelled">Cancelled</span>';
                                ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Recent Users Table -->
        <div class="table-container">
            <div class="table-header-row">
                <h3>Recent Users</h3>
                <a href="manage_user.php" class="btn btn-outline btn-small"><i class="fas fa-users"></i> View All</a>
            </div>
            <table class="responsive-table">
                <thead>
                    <tr>
                        <th>Full Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Joined</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recent_users as $u): ?>
                        <tr>
                            <td style="font-weight: 600;"><?= htmlspecialchars($u['fullname']) ?></td>
                            <td><?= htmlspecialchars($u['email']) ?></td>
                            <td>
                                <?php if ($u['role'] === 'admin'): ?>
                                    <span class="badge badge-admin">Admin</span>
                                <?php else: ?>
                                    <span class="badge badge-user">User</span>
                                <?php endif; ?>
                            </td>
                            <td style="color: var(--text-secondary); font-size: 0.85rem;"><?= date('d M Y', strtotime($u['created_at'])) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<?php require_once '../includes/footer.php'; ?>
