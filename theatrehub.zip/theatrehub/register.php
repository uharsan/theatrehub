<?php
$page_title = "Register";
$base_path = "./";
require_once 'includes/config.php';

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

$errors = [];

if (isset($_POST['register'])) {
    // 1. Sanitization
    $fullname = sanitize_input($_POST['fullname']);
    $email = sanitize_input($_POST['email']);
    $phone = sanitize_input($_POST['phone']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    // 2. Validation
    if (empty($fullname)) {
        $errors['fullname'] = "Full name is required.";
    }
    
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = "A valid email address is required.";
    }
    
    if (empty($phone)) {
        $errors['phone'] = "Phone number is required.";
    }
    
    if (strlen($password) < 6) {
        $errors['password'] = "Password must be at least 6 characters long.";
    }
    
    if ($password !== $confirm_password) {
        $errors['confirm_password'] = "Passwords do not match.";
    }
    
    // 3. Database check and insert if no errors
    if (empty($errors)) {
        try {
            // Check if email already exists
            $stmt = $pdo->prepare("SELECT `user_id` FROM `users` WHERE `email` = ?");
            $stmt->execute([$email]);
            
            if ($stmt->rowCount() > 0) {
                $errors['email'] = "Email is already registered.";
            } else {
                // Hash the password securely
                $hashed_password = password_hash($password, PASSWORD_BCRYPT);
                
                // Insert new user
                $insert_stmt = $pdo->prepare("INSERT INTO `users` (`fullname`, `email`, `password`, `role`, `phone`) VALUES (?, ?, ?, 'user', ?)");
                $insert_stmt->execute([$fullname, $email, $hashed_password, $phone]);
                
                $_SESSION['success'] = "Registration successful! Please login below.";
                header("Location: login.php");
                exit();
            }
        } catch (PDOException $e) {
            $errors['db'] = "Database error: " . $e->getMessage();
        }
    }
}

require_once 'includes/header.php';
?>

<div class="auth-page">
    <div class="auth-card card-form">
        <h3>Create an Account</h3>
        
        <?php if (isset($errors['db'])): ?>
            <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?= $errors['db'] ?></div>
        <?php endif; ?>
        
        <form method="POST" action="register.php" id="register-form">
            <div class="form-group">
                <label for="fullname">Full Name</label>
                <input type="text" name="fullname" id="fullname" class="form-control" placeholder="John Doe" value="<?= isset($fullname) ? htmlspecialchars($fullname) : '' ?>" required>
                <?php if (isset($errors['fullname'])): ?>
                    <span style="color: var(--danger-color); font-size: 0.8rem;"><?= $errors['fullname'] ?></span>
                <?php endif; ?>
            </div>
            
            <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" name="email" id="email" class="form-control" placeholder="john@example.com" value="<?= isset($email) ? htmlspecialchars($email) : '' ?>" required>
                <?php if (isset($errors['email'])): ?>
                    <span style="color: var(--danger-color); font-size: 0.8rem;"><?= $errors['email'] ?></span>
                <?php endif; ?>
            </div>
            
            <div class="form-group">
                <label for="phone">Phone Number</label>
                <input type="text" name="phone" id="phone" class="form-control" placeholder="+91 98765 43210" value="<?= isset($phone) ? htmlspecialchars($phone) : '' ?>" required>
                <?php if (isset($errors['phone'])): ?>
                    <span style="color: var(--danger-color); font-size: 0.8rem;"><?= $errors['phone'] ?></span>
                <?php endif; ?>
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" id="password" class="form-control" placeholder="At least 6 characters" required>
                <?php if (isset($errors['password'])): ?>
                    <span style="color: var(--danger-color); font-size: 0.8rem;"><?= $errors['password'] ?></span>
                <?php endif; ?>
            </div>
            
            <div class="form-group">
                <label for="confirm_password">Confirm Password</label>
                <input type="password" name="confirm_password" id="confirm_password" class="form-control" placeholder="Repeat your password" required>
                <?php if (isset($errors['confirm_password'])): ?>
                    <span style="color: var(--danger-color); font-size: 0.8rem;"><?= $errors['confirm_password'] ?></span>
                <?php endif; ?>
            </div>
            
            <button type="submit" name="register" class="btn btn-primary" style="width: 100%; margin-top: 1rem; border-radius: 8px;">
                <i class="fas fa-user-plus"></i> Register
            </button>
        </form>
        
        <div class="auth-footer-text">
            Already have an account? <a href="login.php">Login</a>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
