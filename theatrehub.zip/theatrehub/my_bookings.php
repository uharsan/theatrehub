<?php
session_start();
require_once 'includes/config.php';
if(!isset($_SESSION['user_id'])){ header("Location: login.php"); exit(); }

$stmt = $pdo->prepare("SELECT b.*, s.show_date, s.show_time, s.screen_name, m.title 
                       FROM bookings b 
                       JOIN shows s ON b.show_id = s.show_id 
                       JOIN movies m ON s.movie_id = m.movie_id 
                       WHERE b.user_id = ? ORDER BY b.booking_id DESC");
$stmt->execute([$_SESSION['user_id']]);
$bookings = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html>
<head><title>My Bookings</title></head>
<body>
<h1>My Bookings</h1>
<?php if(empty($bookings)): ?>
    <p>No bookings yet. <a href="movies.php">Book Now</a></p>
<?php endif; ?>

<?php foreach($bookings as $b): ?>
<div style="border:2px solid blue; padding:15px; margin:10px;">
    <h3><?= $b['title'] ?></h3>
    <p>Booking ID: #<?= $b['booking_id'] ?></p>
    <p>Date: <?= $b['show_date'] ?> | Time: <?= $b['show_time'] ?></p>
    <p>Seats: <b><?= $b['seats'] ?></b></p>
    <p>Amount: LKR <?= $b['total_amount'] ?></p>
    <p>Status: CONFIRMED</p>
</div>
<?php endforeach; ?>
<a href="movies.php">← Back to Movies</a>
</body>
</html>