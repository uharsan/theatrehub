<?php
session_start();
require_once 'includes/config.php';

// Login check
if(!isset($_SESSION['user_id'])){ 
    header("Location: login.php"); 
    exit(); 
}

// DB la irunthu ellam movie eduka
$stmt = $pdo->query("SELECT * FROM movies ORDER BY movie_id DESC");
$movies = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Movies - TheatreHub</title>
    <style>
        body { 
            font-family: 'Segoe UI', Arial, sans-serif; 
            background: #f0f2f5; 
            margin: 0; 
            padding: 20px; 
        }
       .header {
            background: white;
            padding: 15px 25px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
       .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        h1 { 
            color: #1c1e21; 
            margin: 0;
        }
       .movie-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
        }
       .movie-card { 
            background: white; 
            border-radius: 12px; 
            padding: 20px; 
            box-shadow: 0 2px 8px rgba(0,0,0,0.1); 
            text-align: center;
            transition: transform 0.2s;
        }
       .movie-card:hover {
            transform: translateY(-5px);
        }
       .movie-card h3 { 
            margin: 0 0 10px 0; 
            color: #333;
            font-size: 20px;
        }
       .movie-card p { 
            color: #666; 
            margin: 5px 0 15px 0; 
        }
       .btn { 
            background: #1877f2; 
            color: white; 
            padding: 10px 20px; 
            text-decoration: none; 
            border-radius: 6px; 
            display: inline-block;
            font-weight: 600;
        }
       .btn:hover { 
            background: #166fe5; 
        }
       .nav-link {
            text-decoration: none;
            color: #1877f2;
            font-weight: 600;
        }
       .empty-msg {
            background: white;
            padding: 40px;
            text-align: center;
            border-radius: 10px;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Now Showing</h1>
            <div>
                <a class="nav-link" href="dashboard.php">← Dashboard</a> &nbsp; | &nbsp;
                <a class="nav-link" href="my_bookings.php">My Bookings</a> &nbsp; | &nbsp;
                <a class="nav-link" href="logout.php">Logout</a>
            </div>
        </div>

        <?php if(empty($movies)): ?>
            <div class="empty-msg">
                <h2>No movies available right now 😕</h2>
                <p>Admin panel la movies add pannunga bro</p>
            </div>
        <?php else: ?>
            <div class="movie-grid">
                <?php foreach($movies as $m): ?>
                <div class="movie-card">
                    <h3><?= htmlspecialchars($m['title']) ?></h3>
                    <p>Duration: <?= $m['duration'] ?> minutes</p>
                    <a class="btn" href="shows.php?movie_id=<?= $m['movie_id'] ?>">Book Tickets</a>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
