<?php
$page_title = "User Dashboard";
$active_page = "dashboard";
$base_path = "./";
require_once 'includes/config.php';

// Access guard
require_login();

$user_id = $_SESSION['user_id'];
$fullname = $_SESSION['fullname'];

// Handle Cancel Booking Request
if (isset($_POST['cancel_booking'])) {
    $booking_id = filter_var($_POST['booking_id'], FILTER_VALIDATE_INT);
    
    if ($booking_id) {
        try {
            // Confirm the booking belongs to this user
            $chk_stmt = $pdo->prepare("SELECT * FROM `add` WHERE `add_id` = ? AND `user_id` = ?");
            $chk_stmt->execute([$booking_id, $user_id]);
            
            if ($chk_stmt->rowCount() > 0) {
                // Update status to Cancelled
                $upd_stmt = $pdo->prepare("UPDATE `add` SET `status` = 'Cancelled' WHERE `add_id` = ?");
                $upd_stmt->execute([$booking_id]);
                $_SESSION['success'] = "Booking cancelled successfully.";
            } else {
                $_SESSION['error'] = "Unauthorized or invalid booking cancellation.";
            }
        } catch (PDOException $e) {
            $_SESSION['error'] = "Failed to cancel booking: " . $e->getMessage();
        }
        header("Location: dashboard.php");
        exit();
    }
}

// Fetch user dashboard statistics
try {
    // Total Bookings
    $total_stmt = $pdo->prepare("SELECT COUNT(*) FROM `add` WHERE `user_id` = ?");
    $total_stmt->execute([$user_id]);
    $total_bookings = $total_stmt->fetchColumn();
    
    // Upcoming Bookings
    $up_stmt = $pdo->prepare("SELECT COUNT(*) FROM `add` WHERE `user_id` = ? AND `status` = 'Upcoming'");
    $up_stmt->execute([$user_id]);
    $upcoming_bookings = $up_stmt->fetchColumn();
    
    // Completed Bookings
    $comp_stmt = $pdo->prepare("SELECT COUNT(*) FROM `add` WHERE `user_id` = ? AND `status` = 'Completed'");
    $comp_stmt->execute([$user_id]);
    $completed_bookings = $comp_stmt->fetchColumn();
    
    // Cancelled Bookings
    $canc_stmt = $pdo->prepare("SELECT COUNT(*) FROM `add` WHERE `user_id` = ? AND `status` = 'Cancelled'");
    $canc_stmt->execute([$user_id]);
    $cancelled_bookings = $canc_stmt->fetchColumn();
    
    // Fetch bookings list
    $bookings_stmt = $pdo->prepare("SELECT a.add_id, a.features_name, a.status, f.facilities 
                                    FROM `add` a 
                                    JOIN `features` f ON a.features_name = f.features_name 
                                    WHERE a.user_id = ? 
                                    ORDER BY a.add_id DESC");
    $bookings_stmt->execute([$user_id]);
    $bookings = $bookings_stmt->fetchAll();
} catch (PDOException $e) {
    $_SESSION['error'] = "Failed to load dashboard data: " . $e->getMessage();
    $total_bookings = 0;
    $upcoming_bookings = 0;
    $completed_bookings = 0;
    $cancelled_bookings = 0;
    $bookings = [];
}

require_once 'includes/header.php';
?>

<div class="dashboard-grid">
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-title">Menu</div>
        <ul class="sidebar-menu">
            <li><a href="dashboard.php" class="active"><i class="fas fa-ticket-alt"></i> My Bookings</a></li>
            <li><a href="profile.php"><i class="fas fa-user-circle"></i> Profile</a></li>
            <li><a href="profile.php#change-password"><i class="fas fa-key"></i> Change Password</a></li>
            <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </aside>

    <!-- Main Content -->
    <main class="dashboard-content">
        <!-- Welcome Banner -->
        <div style="background-color: var(--bg-secondary); border: 1px solid var(--border-color); padding: 1.5rem 2rem; border-radius: var(--border-radius); border-left: 4px solid var(--primary-color);">
            <h2 style="font-family: var(--font-heading);">Welcome, <?= htmlspecialchars($fullname) ?>! 🍿</h2>
            <p style="color: var(--text-secondary); font-size: 0.9rem; margin-top: 0.25rem;">Manage your tickets, view schedules, and keep track of your entertainment bookings.</p>
        </div>

        <!-- Statistics Grid -->
        <div class="stats-grid">
            <div class="stat-card">
                <span class="stat-card-title">My Bookings</span>
                <span class="stat-card-value"><?= $total_bookings ?></span>
                <span class="stat-card-desc" style="color: var(--text-secondary);">Total history</span>
            </div>
            
            <div class="stat-card">
                <span class="stat-card-title">Upcoming</span>
                <span class="stat-card-value" style="color: var(--success-color);"><?= $upcoming_bookings ?></span>
                <span class="stat-card-desc">Active tickets</span>
            </div>
            
            <div class="stat-card">
                <span class="stat-card-title">Completed</span>
                <span class="stat-card-value" style="color: var(--text-secondary);"><?= $completed_bookings ?></span>
                <span class="stat-card-desc" style="color: var(--text-secondary);">Watched shows</span>
            </div>
            
            <div class="stat-card">
                <span class="stat-card-title">Cancelled</span>
                <span class="stat-card-value" style="color: var(--danger-color);"><?= $cancelled_bookings ?></span>
                <span class="stat-card-desc" style="color: var(--danger-color);">Cancelled tickets</span>
            </div>
        </div>

        <!-- Bookings List Table -->
        <div class="table-container">
            <div class="table-header-row">
                <h3>My Bookings</h3>
                <a href="features.php" class="btn btn-primary btn-small"><i class="fas fa-plus"></i> New Booking</a>
            </div>
            
            <table class="responsive-table">
                <thead>
                    <tr>
                        <th>Booking ID</th>
                        <th>Movie Name</th>
                        <th>Facilities / Specs</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($bookings)): ?>
                        <?php foreach ($bookings as $booking): ?>
                            <tr>
                                <td>#<?= str_pad($booking['add_id'], 4, '0', STR_PAD_LEFT) ?></td>
                                <td style="font-weight: 600;"><?= htmlspecialchars($booking['features_name']) ?></td>
                                <td style="font-size: 0.8rem; color: var(--text-secondary);"><?= htmlspecialchars($booking['facilities']) ?></td>
                                <td>
                                    <?php 
                                    $status = strtolower($booking['status']);
                                    if ($status === 'upcoming') {
                                        echo '<span class="badge badge-upcoming">Upcoming</span>';
                                    } elseif ($status === 'completed') {
                                        echo '<span class="badge badge-completed">Completed</span>';
                                    } else {
                                        echo '<span class="badge badge-cancelled">Cancelled</span>';
                                    }
                                    ?>
                                </td>
                                <td>
                                    <?php if ($status === 'upcoming'): ?>
                                        <form method="POST" action="" onsubmit="return confirm('Are you sure you want to cancel this booking?');">
                                            <input type="hidden" name="booking_id" value="<?= $booking['add_id'] ?>">
                                            <button type="submit" name="cancel_booking" class="btn btn-outline btn-small" style="color: var(--danger-color); border-color: rgba(230, 57, 70, 0.3);">
                                                Cancel
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <span style="color: var(--text-secondary); font-size: 0.8rem;">No Actions</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" style="text-align: center; padding: 3rem; color: var(--text-secondary);">
                                <i class="fas fa-ticket-alt" style="font-size: 2rem; color: var(--primary-color); margin-bottom: 1rem; display: block;"></i>
                                You haven't booked any movies yet. 
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<?php require_once 'includes/footer.php'; ?>
