<?php
$page_title = "Home";
$active_page = "home";
$base_path = "./";
require_once 'includes/config.php';

// Helper to get image sources
function get_movie_image($image) {
    $local_path = 'assets/images/' . $image;
    if (file_exists($local_path) && !is_dir($local_path)) {
        return $local_path;
    }
    
    // Premium Unsplash fallback image mappings based on seed values
    $fallbacks = [
        'kalki.jpg' => 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=500&q=80', // Sci-fi Cosmos
        'leo.jpg' => 'https://images.unsplash.com/photo-1546182990-dffeafbe841d?auto=format&fit=crop&w=500&q=80',   // Lion
        'goat.jpg' => 'https://images.unsplash.com/photo-1506318137071-a8e063b4bec0?auto=format&fit=crop&w=500&q=80',  // Cosmic spy
        'jailer.jpg' => 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&w=500&q=80',// Prison gate/justice
        'devara.jpg' => 'https://images.unsplash.com/photo-1505118380757-91f5f5632de0?auto=format&fit=crop&w=500&q=80',// Coast/stormy sea
        'vettaiyan.jpg' => 'https://images.unsplash.com/photo-1453873531674-215110190687?auto=format&fit=crop&w=500&q=80', // Police/detective
        'dune2.jpg' => '4.jpg',  // Desert dunes
        'maharaja.jpg' => '3.jpg',// Barber shop
        'kanguva.jpg' => '2.jpg', // Historic warrior fire
        'amaran.jpg' => '1.jpg'   // Army/badge
    ];
    
    return isset($fallbacks[$image]) ? $fallbacks[$image] : 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=500&q=80';
}

// Fetch 4 featured movies/features
try {
    $stmt = $pdo->query("SELECT * FROM `features` ORDER BY `created_at` DESC LIMIT 4");
    $featured_movies = $stmt->fetchAll();
} catch (PDOException $e) {
    $featured_movies = [];
}

// Handle quick booking directly from home page
if (isset($_POST['book_now'])) {
    if (!isset($_SESSION['user_id'])) {
        $_SESSION['error'] = "Please login first to book tickets.";
        header("Location: login.php");
        exit();
    }
    
    $user_id = $_SESSION['user_id'];
    $movie_name = sanitize_input($_POST['movie_name']);
    
    try {
        // Double check movie exists
        $chk_stmt = $pdo->prepare("SELECT * FROM `features` WHERE `features_name` = ?");
        $chk_stmt->execute([$movie_name]);
        if ($chk_stmt->rowCount() > 0) {
            // Book the movie in 'add' table
            $book_stmt = $pdo->prepare("INSERT INTO `add` (`user_id`, `features_name`, `status`) VALUES (?, ?, ?)");
            $book_stmt->execute([$user_id, $movie_name, 'Upcoming']);
            $_SESSION['success'] = "Successfully booked tickets for " . htmlspecialchars($movie_name) . "!";
            header("Location: dashboard.php");
            exit();
        } else {
            $_SESSION['error'] = "Selected movie is not available.";
        }
    } catch (PDOException $e) {
        $_SESSION['error'] = "Booking failed. Please try again. Error: " . $e->getMessage();
    }
}

require_once 'includes/header.php';
?>

<!-- Hero Banner -->
<div class="hero">
    <div class="hero-container">
        <div class="hero-content">
            <h1>Welcome to<br><span>TheatreHub</span></h1>
            <p>Book your favorite movies, best seats, best experience. Experience cinema in premium visual clarity with Dolby Atmos Surround Sound system.</p>
            <div class="hero-actions">
                <a href="features.php" class="btn btn-primary"><i class="fas fa-ticket-alt"></i> Book Tickets</a>
                <a href="#now-showing" class="btn btn-outline"><i class="fas fa-play"></i> Explore Movies</a>
            </div>
        </div>
        <div class="hero-image">
            <img src="https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?auto=format&fit=crop&w=600&q=80" alt="Theatre Seat Cinema Poster">
        </div>
    </div>
</div>

<!-- Now Showing -->
<section id="now-showing">
    <div class="section-header">
        <div class="section-title">
            <h2>Now Showing</h2>
            <p>Catch the latest blockbusters on screen today</p>
        </div>
        <a href="features.php" class="btn btn-outline btn-small">View All</a>
    </div>
    
    <div class="grid-cards">
        <?php if (!empty($featured_movies)): ?>
            <?php foreach ($featured_movies as $movie): ?>
                <div class="movie-card">
                    <div class="movie-poster">
                        <img src="<?= get_movie_image($movie['image']) ?>" alt="<?= htmlspecialchars($movie['features_name']) ?>">
                        <span class="movie-badge"><i class="fas fa-star"></i> 4.8</span>
                    </div>
                    <div class="movie-info">
                        <h3 class="movie-title"><?= htmlspecialchars($movie['features_name']) ?></h3>
                        <div class="movie-meta">
                            <span><i class="fas fa-film"></i> Action</span>
                            <span><i class="fas fa-clock"></i> 2h 45m</span>
                        </div>
                        <p class="movie-desc"><?= htmlspecialchars($movie['description']) ?></p>
                        <div class="movie-facilities">
                            <i class="fas fa-cogs"></i> <?= htmlspecialchars($movie['facilities']) ?>
                        </div>
                        
                        <form method="POST" action="">
                            <input type="hidden" name="movie_name" value="<?= htmlspecialchars($movie['features_name']) ?>">
                            <button type="submit" name="book_now" class="btn btn-primary" style="width: 100%;">
                                <i class="fas fa-ticket-alt"></i> Book Now
                            </button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div style="grid-column: 1/-1; text-align: center; padding: 3rem; background-color: var(--bg-secondary); border-radius: var(--border-radius); border: 1px solid var(--border-color);">
                <i class="fas fa-info-circle" style="font-size: 2rem; color: var(--primary-color); margin-bottom: 1rem;"></i>
                <p>No movies currently playing. Check back later!</p>
            </div>
        <?php endif; ?>
    </div>
</section>

<!-- Why Choose Us -->
<section style="background-color: var(--bg-secondary); max-width: 100%; width: 100%; border-top: 1px solid var(--border-color); border-bottom: 1px solid var(--border-color);">
    <div style="max-width: 1200px; margin: 0 auto;">
        <div class="section-title" style="text-align: center; margin-bottom: 3rem;">
            <h2>Outstanding Cinema Facilities</h2>
            <p>Elevating your movie-watching experience to new heights</p>
        </div>
        
        <div class="about-features" style="margin-top: 0;">
            <div class="about-card">
                <div class="about-card-icon"><i class="fas fa-volume-up"></i></div>
                <h3>Best Sound Quality</h3>
                <p>Equipped with state-of-the-art Dolby Atmos spatial audio system for ultimate immersion.</p>
            </div>
            
            <div class="about-card">
                <div class="about-card-icon"><i class="fas fa-couch"></i></div>
                <h3>Comfortable Seating</h3>
                <p>Premium leather recliner seats with ample legroom designed for maximum physical comfort.</p>
            </div>
            
            <div class="about-card">
                <div class="about-card-icon"><i class="fas fa-mobile-alt"></i></div>
                <h3>Online Ticket Booking</h3>
                <p>Book tickets directly from our mobile-friendly dashboard without waiting in long queues.</p>
            </div>
            
            <div class="about-card">
                <div class="about-card-icon"><i class="fas fa-headset"></i></div>
                <h3>24/7 Support</h3>
                <p>Our dedicated support team is available round the clock to resolve ticket-related queries.</p>
            </div>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
