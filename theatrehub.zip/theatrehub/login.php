<?php
$page_title = "Login";
$base_path = "./";
require_once 'includes/config.php';

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['role'] === 'admin') {
        header("Location: admin/admin_dashboard.php");
    } else {
        header("Location: dashboard.php");
    }
    exit();
}

$errors = [];

if (isset($_POST['login'])) {
    // 1. Sanitization
    $email = sanitize_input($_POST['email']);
    $password = $_POST['password'];
   
    // 2. Validation
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = "Please enter a valid email address.";
    }
   
    if (empty($password)) {
        $errors['password'] = "Password is required.";
    }
   
    // 3. Authenticate
    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("SELECT * FROM `users` WHERE `email` = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();
           
            if ($user && password_verify($password, $user['password'])) {
                // Generate a session ID to prevent session fixation
                session_regenerate_id(true);
               
                // Store user details in session
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['fullname'] = $user['fullname'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['phone'] = $user['phone'];
               
                $_SESSION['success'] = "Welcome back, " . htmlspecialchars($user['fullname']) . "!";
               
                // Redirect depending on role
                if ($user['role'] === 'admin') {
                    header("Location: admin/admin_dashboard.php");
                } else {
                    header("Location: dashboard.php");
                }
                exit();
            } else {
                $errors['auth'] = "Incorrect email address or password.";
            }
        } catch (PDOException $e) {
            $errors['db'] = "Database error: " . $e->getMessage();
        }
    }
}

require_once 'includes/header.php';
?>

<div class="auth-page">
    <div class="auth-card card-form">
        <h3>Login to Your Account</h3>
       
        <?php if (isset($errors['auth'])): ?>
            <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?= $errors['auth'] ?></div>
        <?php endif; ?>
        <?php if (isset($errors['db'])): ?>
            <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?= $errors['db'] ?></div>
        <?php endif; ?>
       
        <form method="POST" action="login.php" id="login-form">
            <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" name="email" id="email" class="form-control" placeholder="john@example.com" value="<?= isset($email) ? htmlspecialchars($email) : '' ?>" required>
                <?php if (isset($errors['email'])): ?>
                    <span style="color: var(--danger-color); font-size: 0.8rem;"><?= $errors['email'] ?></span>
                <?php endif; ?>
            </div>
           
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" id="password" class="form-control" placeholder="Enter your password" required>
                <?php if (isset($errors['password'])): ?>
                    <span style="color: var(--danger-color); font-size: 0.8rem;"><?= $errors['password'] ?></span>
                <?php endif; ?>
            </div>
           
            <div class="form-group" style="display: flex; justify-content: space-between; align-items: center; margin-top: 1rem;">
                <label style="display: flex; align-items: center; gap: 8px; font-size: 0.8rem; cursor: pointer;">
                    <input type="checkbox" name="remember" style="accent-color: var(--primary-color);"> Remember Me
                </label>
                <a href="#" style="font-size: 0.8rem; color: var(--primary-color); text-decoration: none;" onclick="alert('Password recovery feature is not included in the assignment guidelines.')">Forgot Password?</a>
            </div>
           
            <button type="submit" name="login" class="btn btn-primary" style="width: 100%; margin-top: 1.5rem; border-radius: 8px;">
                <i class="fas fa-sign-in-alt"></i> Login
            </button>
        </form>
       
        <div class="auth-footer-text">
            Don't have an account? <a href="register.php">Register</a>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
