<?php
require_once 'includes/config.php';

if(!isset($_SESSION['user_id'])){ 
    header("Location: login.php"); 
    exit(); 
}

if(!isset($_POST['seats']) || !isset($_POST['show_id']) || !isset($_POST['total'])){
    die("Invalid request. <a href='movies.php'>Go back</a>");
}

$user_id = $_SESSION['user_id'];
$show_id = $_POST['show_id'];
$seats = $_POST['seats'];
$total = $_POST['total'];

if(empty($seats)){
    die("No seats selected. <a href='seat_selection.php?show_id=$show_id'>Go back</a>");
}

$seats_array = explode(',', $seats);

try {
    $pdo->beginTransaction();

    $stmt = $pdo->prepare("SELECT seats FROM bookings WHERE show_id = ?");
    $stmt->execute([$show_id]);
    $already_booked = [];
    while($row = $stmt->fetch()){
        $already_booked = array_merge($already_booked, explode(',', $row['seats']));
    }

    foreach($seats_array as $seat){
        if(in_array($seat, $already_booked)){
            $pdo->rollBack();
            die("Sorry, Seat $seat already booked. <a href='seat_selection.php?show_id=$show_id'>Choose again</a>");
        }
    }

    $stmt = $pdo->prepare("SELECT price FROM shows WHERE show_id = ?");
    $stmt->execute([$show_id]);
    $show = $stmt->fetch();
    $correct_total = $show['price'] * count($seats_array);
    
    if($total != $correct_total){
        $pdo->rollBack();
        die("Price mismatch. <a href='seat_selection.php?show_id=$show_id'>Go back</a>");
    }

    $stmt = $pdo->prepare("INSERT INTO bookings (user_id, show_id, seats, total_amount, payment_id) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$user_id, $show_id, $seats, $total, 'FREE_BOOKING']);

    $pdo->commit();
    
    $_SESSION['success'] = "Booking confirmed! Download your ticket below.";
    header("Location: my_bookings.php");
    exit();

} catch(PDOException $e) {
    $pdo->rollBack();
    die("Booking failed: " . $e->getMessage());
}
?>