<?php
// Determine the base path dynamically if not set
if (!isset($base_path)) {
    $base_path = './';
}
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($page_title) ? $page_title . ' - TheatreHub' : 'TheatreHub - Premium Movie Booking' ?></title>
    
    <!-- Link Stylesheets -->
    <link rel="stylesheet" href="<?= $base_path ?>assets/css/style.css">
    
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Google Fonts are preloaded in CSS, script is deferred -->
    <script src="<?= $base_path ?>assets/js/script.js" defer></script>
</head>
<body>
    <header>
        <div class="nav-container">
            <a href="<?= $base_path ?>index.php" class="logo-link">
                <i class="fas fa-ticket-alt logo-icon"></i>
                <span class="logo-text">Theatre<span style="color: var(--primary-color);">Hub</span></span>
            </a>
            
            <button class="mobile-nav-toggle" id="mobile-nav-toggle" aria-label="Toggle Navigation">
                <i class="fas fa-bars"></i>
            </button>
            
            <nav>
                <ul>
                    <li><a href="<?= $base_path ?>index.php" class="<?= isset($active_page) && $active_page == 'home' ? 'active' : '' ?>">Home</a></li>
                    <li><a href="<?= $base_path ?>about-us.php" class="<?= isset($active_page) && $active_page == 'about' ? 'active' : '' ?>">About Us</a></li>
                    <li><a href="<?= $base_path ?>features.php" class="<?= isset($active_page) && $active_page == 'features' ? 'active' : '' ?>">Movies</a></li>
                    <li><a href="<?= $base_path ?>contact-us.php" class="<?= isset($active_page) && $active_page == 'contact' ? 'active' : '' ?>">Contact Us</a></li>
                </ul>
            </nav>
            
            <div class="nav-right">
                <button class="theme-switch" id="theme-switch" title="Toggle Theme">
                    <i class="fas fa-sun"></i>
                </button>
                
                <?php if (isset($_SESSION['user_id'])): ?>
                    <!-- Logged in state -->
                    <?php if ($_SESSION['role'] === 'admin'): ?>
                        <a href="<?= $base_path ?>admin/admin_dashboard.php" class="btn btn-outline btn-small <?= isset($active_page) && $active_page == 'dashboard' ? 'active' : '' ?>">
                            <i class="fas fa-columns"></i> Admin Panel
                        </a>
                    <?php else: ?>
                        <a href="<?= $base_path ?>dashboard.php" class="btn btn-outline btn-small <?= isset($active_page) && $active_page == 'dashboard' ? 'active' : '' ?>">
                            <i class="fas fa-user"></i> Dashboard
                        </a>
                    <?php endif; ?>
                    <a href="<?= $base_path ?>logout.php" class="btn btn-primary btn-small">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                <?php else: ?>
                    <!-- Logged out state -->
                    <a href="<?= $base_path ?>login.php" class="btn btn-outline btn-small">Login</a>
                    <a href="<?= $base_path ?>register.php" class="btn btn-primary btn-small">Register</a>
                <?php endif; ?>
            </div>
        </div>
    </header>
    
    <!-- Display session flash notifications if any -->
    <div style="max-width: 1200px; margin: 1.5rem auto 0 auto; padding: 0 2rem;">
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <?= $_SESSION['success']; unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i>
                <?= $_SESSION['error']; unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>
    </div>
