<?php
// Determine the base path dynamically if not set
if (!isset($base_path)) {
    $base_path = './';
}
?>
    <footer>
        <div class="footer-container">
            <div class="footer-brand">
                <a href="<?= $base_path ?>index.php" class="logo-link" style="margin-bottom: 0.5rem;">
                    <i class="fas fa-ticket-alt logo-icon"></i>
                    <span class="logo-text">Theatre<span style="color: var(--primary-color);">Hub</span></span>
                </a>
                <p>Book your favorite movies, best seats, best experience. Get ready for premium entertainment and cinematic experience at its finest.</p>
                <div class="social-links" style="margin-top: 0.5rem;">
                    <a href="#" class="social-icon" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" class="social-icon" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
                    <a href="#" class="social-icon" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                    <a href="#" class="social-icon" aria-label="YouTube"><i class="fab fa-youtube"></i></a>
                </div>
            </div>
            
            <div class="footer-col">
                <h4>Quick Links</h4>
                <ul>
                    <li><a href="<?= $base_path ?>index.php">Home</a></li>
                    <li><a href="<?= $base_path ?>about-us.php">About Us</a></li>
                    <li><a href="<?= $base_path ?>features.php">Movies</a></li>
                    <li><a href="<?= $base_path ?>contact-us.php">Contact Us</a></li>
                </ul>
            </div>
            
            <div class="footer-col">
                <h4>User Links</h4>
                <ul>
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <li><a href="<?= $base_path ?>dashboard.php">My Bookings</a></li>
                        <li><a href="<?= $base_path ?>profile.php">Profile</a></li>
                        <li><a href="<?= $base_path ?>profile.php#change-password">Change Password</a></li>
                        <li><a href="<?= $base_path ?>logout.php">Logout</a></li>
                    <?php else: ?>
                        <li><a href="<?= $base_path ?>login.php">Login</a></li>
                        <li><a href="<?= $base_path ?>register.php">Register</a></li>
                    <?php endif; ?>
                </ul>
            </div>
            
            <div class="footer-col">
                <h4>Support</h4>
                <ul>
                    <li><a href="#">Help Center</a></li>
                    <li><a href="#">Terms & Conditions</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                    <li><a href="#">FAQ</a></li>
                </ul>
            </div>
            
            <div class="footer-col">
                <h4>Contact Us</h4>
                <p><i class="fas fa-phone-alt" style="color: var(--primary-color); margin-right: 8px;"></i> +91 98765 43210</p>
                <p><i class="fas fa-envelope" style="color: var(--primary-color); margin-right: 8px;"></i> info@theatrehub.com</p>
                <p><i class="fas fa-map-marker-alt" style="color: var(--primary-color); margin-right: 8px;"></i> 123, Main Street, Chennai - 600001</p>
            </div>
        </div>
        
        <div class="footer-bottom">
            <p>&copy; <?= date('Y') ?> TheatreHub. All Rights Reserved.</p>
            <p>Designed for HDIT 21193 - User Experience and Interface Design</p>
        </div>
    </footer>
</body>
</html>
